// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Photon.cc
 * \brief The Photon class creates a photon with a predifined specifications
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */

#include "Photon.h"
#include <sstream>

Photon::Photon() {
}

Photon::~Photon() {
}

Photon::Photon(double e, double tx, double ty, double x, double y,double z, double p) {
	_ephot=e;
	_thetax=tx;
	_thetay=ty;
	_xemis = x;
	_yemis = y;
	_zemis=z;
	_poids=p;
}

string Photon::outputFlow() const{
 ostringstream sortie;

//   sortie <<  " ehpot: " <<  _ephot <<  " thetax: " <<  _thetax << " thetay: " <<  _thetay <<  " zemis: " << _zemis <<  " poids: " <<  _poids << endl;
  sortie <<  "  " <<  _ephot <<  "  " <<  _thetax << "  " <<  _thetay <<  "  " << _zemis <<  "  " <<  _poids << endl;
 return sortie.str();

}


void Photon::print() const{
  cout << outputFlow();
}
