// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file PhotonCollection.cc
 * \brief The PhotonCollection class creates a collection of photons
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */

#include "PhotonCollection.h"
#include <fstream>
#include "GlobalConstants.h"
#include <iostream>



void PhotonCollection::saveOnFile(string filename)
{
	ofstream output_file;
output_file.open(filename.c_str());
  list<Photon>::const_iterator it;
	int numero = 1;
	
	  for (it = _photon.begin(); it != _photon.end(); it++)
    {
      //		output_file << numero << it->print() ;
      output_file << numero << it->outputFlow() ;

      numero++;
    }
	output_file.close();
	_currentIterator = _photon.begin();
}


const Photon* PhotonCollection::getNextPhoton(){
  if(_currentIterator != _photon.end()){
    const Photon* p = &(*_currentIterator);
    _currentIterator++;
		
    return p;
  }
  else{
    return NULL;
  }
}




void PhotonCollection::printPhotons() const
{
  list<Photon>::const_iterator it;
  int compteur = 1;
  for (it = _photon.begin(); it != _photon.end(); it++)
    {
      std::cout <<"photon n° " << compteur;
      it->print();
      //      it->print(); 
      compteur++;
    }
}
