/*
 *  main.cpp
 *  
 *
 *  Created by Berte on 23/07/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include <math.h>


#include "Fot.h"
#include "ParticleCollection.h"
#include "GlobalConstants.h"
#include "RunParameters.h"

#ifdef TEST_WCLASS
double WCLASS;
#endif


int main(int args,char *argv[]){

  const CrystalW111*  crys = new CrystalW111();    // crys("W",111);
  cout << " cristal tungstene " << endl;
  // PARAMETRES DU RUN
  double phomin = 1.0e-2;
  double etmax = 100000.0;
  double vtmax = 1e-2;
  double zexit = 1.e6;
  double poimin = 1.0;	
  double frekuma = 3.0/MC_OVER_HBAR;			
  RunParameters rp(crys);
  rp.setZexit(zexit);
  rp.set( phomin, etmax, vtmax, poimin, frekuma);

  Fot f(rp);

  ParticleCollection partColl;
  partColl.fill(string("lot.dat"), 1, 5000);

  //partColl.saveOnFile("bidon.dat");

  //   double einit = 3.0;
  //   int ntir = 5000;
  //   double xmx = 0.0;
  //   double xmy = 0.0;
  //   double xmvx = 0.0;
  //   double xmvy = 0.0;
  //   double sx = 50.0;
  //   double sy = 50.0;
  //   double svx = 0.0;
  //   double svy = 0.0;
  //   ParticleCollection partColl(einit, ntir, xmx, xmy, xmvx, xmvy, sx, sy, svx,svy);


  //   f.make();
  cout << " c'est parti " << endl;
      f.makeKumakhov(partColl);

// const Particle* part = partColl.initParticleIteration();
// ParticleInCrystal partCrys = f.makeSingleParticleKumakhov(part);
//  partCrys.printParticle();
      delete crys;
}
