// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Fot.cc
 * \brief The Fot class implements the phenomenon of channeling
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */

#include "Fot.h"
#include "Evenement.h"
#include "version.h"

Fot::Fot(RunParameters& rp) : _runPar(rp), _snak(NULL),  _partCrys(NULL)
{
#ifdef DO_STATS
 _stat = new statistiques;
_stat->zeros();
#else
 _stat = NULL;
#endif

      _zexit = _runPar.getZexit();
      _runPar.getEjectionCut_off(_etmax, _vtmax);
 _nevnt  = 0;

 
}


Fot::~Fot() 
{
  if ( _snak != NULL ) delete _snak;
  if ( _partCrys != NULL ) delete _partCrys;
  if ( _stat != NULL ) delete _stat;
}




void Fot::makeKumakhov(ParticleCollection& partColl)
{

  cout << " FOTPP version " << VERSION << " run makeKumakhov "<<endl;

  try
    {
#ifdef DO_STATS
      _stat->zeros();	
#endif
      const Particle* part = partColl.initParticleIteration();      
      BremsStrahlung* bremse = NULL;

      _nevnt  = 0;

#ifdef TEST_WCLASS
      WCLASS = 0.0; // TEST REGLE DE SOMME
#endif


      while(part != NULL)
	{
	  _nevnt++;
	  makeSingleParticleKumakhov(part);
	  part = partColl.getNextParticle();
	} //   fin boucle particule


      _photons.saveOnFile("photons.dat");
	
      finir();
      cout << " nombre de photons " << _photons.getNbPhotons() << endl;
    }

  catch (string erreur)
    {
      if ( erreur == string("poirot") ) poirot();
      else
	{
	  cerr << " error " << erreur << " not managed " << endl;
	}
    }
}


const ParticleInCrystal& Fot::makeSingleParticleKumakhov(const Particle* part)
{



      BremsStrahlung* bremse = NULL;


      if ( _partCrys != NULL ) delete _partCrys;

      _partCrys = new ParticleInCrystal(_runPar.getCrys(),*part, _runPar.getZexit());

      _snak = new Snake(_runPar, *_partCrys, _photons, _trigo, _stat);
#ifdef DO_STATS
      _stat->incrementNevnt();
      _stat->reset();
#endif
#ifndef TEST_WCLASS
      bremse = new BremsStrahlung( _photons, _trigo, _runPar.getPhomin(), _runPar.getPoimin(), _stat);
#endif
      Evenement eve( _snak, bremse, &_photons, _etmax, _vtmax, _zexit);
      bool suite = true;

      // calcul proprement dit
      while (suite) 
	{
	  suite =   eve.makeStep();  
	} // fin boucle 30

#ifdef DO_STATS
      _stat->addEvent();
#endif
      delete _snak;
      _snak = NULL;
      if ( bremse != NULL ) delete bremse;

	
      //      cout << " nombre de photons " << _photons.getNbPhotons() << endl;
      return *_partCrys;
}



void Fot::poirot() 
{
  cout << " ***************************************************************** " << endl;
  cout << " FOTPP Blague!... POIROT :   " << endl;
  _snak->printPoirot();
#ifdef DO_STATS
  _stat->printPoirot();
#endif
  _partCrys->printPoirot();
  cout << " EPOT= " << _lind._epot << " FX= " << _lind._fx << " FY= " << _lind._fy  << " F= " << _lind._f  << endl;
  cout << " ***************************************************************** " << endl;
  finir();
}





