// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Particle.cc
 * \brief The Particle class provides data and methods for a paticle (electron or positron)
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */

#include "Particle.h"

Particle::Particle()  {;}
Particle::Particle(const Particle& part)
{
  _charge = part._charge;
  _xPosition=part._xPosition;
  _yPosition=part._yPosition;
  _rayon = sqrt( _xPosition*_xPosition + _yPosition*_yPosition);
  _zPosition=part._zPosition;
  _px=part._px;
  _py=part._py;
  _gamma=part._gamma;
  _isPosit = part._isPosit;
}



Particle::Particle(double ch, double x, double y, double z, double px, double py, double g) {
  _charge = ch;
  _xPosition=x;
  _yPosition=y;
  _rayon = sqrt( _xPosition*_xPosition + _yPosition*_yPosition);
  _zPosition=z;
  _px=px;
  _py=py;
  _gamma=g;
  if ( _charge > 0.0 ) _isPosit = true;
  else _isPosit = false;
}

Particle::~Particle() {;}

// double Particle::getCharge() const
// {
//   return _charge; 
// }





void Particle::printParticle() const{
  double EGeV = _gamma* ELECTRON_MASS_GEV;
  double vx = _px/_gamma;
  double vy = _py/_gamma;
  int lposit= 0;
  if ( _charge > 0.0 ) lposit = 1;
  if ( _charge > 0.0 ) lposit = 1;
  printf(" x= %20.17e y= %20.17e z= %20.17e \n", _xPosition,  _yPosition, _zPosition);
  std::cout <<  " egev: " << EGeV << " px: " << _px << "py: " << _py << " lposit= "<< lposit << std::endl;
}


ParticleInCrystal::ParticleInCrystal(const Crystal* crys, const Particle& part, double Zexit) : Particle(part),  _x0cell(0.0), _y0cell(0.0), _ientree(true), _iexit(false), _iemis(false), _crys(crys)
{
  _Zexit = Zexit;
_nsaut = 0;
}


ParticleInCrystal::~ParticleInCrystal()  {;}

//Vraie si la particule a migre vers une autre cellule
bool ParticleInCrystal::anyMigration() {
  PositionInCell pc;
  pc.set( _xPosition, _yPosition, _x0cell, _y0cell); 
 migrationInCrystal(pc);
    return pc.migrated;
}




//Vraie si la particule a migre vers une autre cellule
bool ParticleInCrystal::smallMigration() {
  PositionInCell pc;
  pc.set( _xPosition, _yPosition, _x0cell, _y0cell); 
  migrationInCrystal(pc);
  if (pc.bigJump )
    {
      cerr << " ParticleInCrystal::migration : jump is to big " << endl;
      throw string("poirot");
    }
    return pc.migrated;
}



  void ParticleInCrystal::reIniCoorAndCell(double x, double y, double xCell, double yCell)
{
  _xPosition = x;
  _yPosition = y;
  _rayon = sqrt( _xPosition*_xPosition + _yPosition*_yPosition);
  _x0cell = xCell;
  _y0cell = yCell;
}







