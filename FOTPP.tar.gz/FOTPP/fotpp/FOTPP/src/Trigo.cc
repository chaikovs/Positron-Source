// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//
// ********************************************************************
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Trigo.cc
 * \brief The Trigo class provides a tabulation of the functions cosinus and sinus
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */

#include "Trigo.h"


Trigo::Trigo()
{
	_cosw = vector<double>(_LONG_TRIGO+1);
	_sinw = vector<double>(_LONG_TRIGO+1);
	double pas = PI * 2.0 / _LONG_TRIGO;
	double a =0.0;
	for (int i = 0; i <= _LONG_TRIGO; i++){
		_cosw[i] = cos(a);
		_sinw[i] = sin(a);
		a+= pas;
	}
	
	_tanw0 = 2 * tan( PI / _LONG_TRIGO);
}
	
double Trigo::getDimension() const
{
  return _LONG_TRIGO;
}

double Trigo::getCosw( int k) const
{
	return _cosw[k];
}


double Trigo::getSinw(int k) const 
{
	return _sinw[k];
}


double Trigo::getTanw0() const
{
	return _tanw0;
}

