// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file rndm.cc
 * \brief random generator
 * \author Guy LE MEUR (from guineapig, Daniel Schulte, CERN)
 * \date 01.09.2010
 */

//#include <cstdio>
#include <iostream>
#include <fstream>
#include <cmath>
#include "rndm.h"
#include "GlobalConstants.h"

using namespace std;

RNDM::RNDM()
{
  ;
}

RNDM::RNDM(unsigned long seed)
{
  init(seed);
}


void RNDM::init(unsigned long seed)
{

//   cout << " RNDM:: ATTENTION ALEATOIRE DETERMINISTE " << endl;
//   double alea1, alea2, alea3;
//     string nomAlea = string("alea.dat");
//   ifstream input_file;
//   input_file.open(nomAlea.c_str());
//   if ( !input_file )
//     {
//       cout << " ParticleCollection::fill : could not open the file " << nomAlea << endl;
//       exit(0);
//     }
//   while ( input_file >> alea1 >>  alea2 >> alea3)
//     {
//       alea_.push_back(alea1);
//       alea_.push_back(alea2);
//       alea_.push_back(alea3);
//     }
//   input_file.close();
//   suivant_ = 0;
//   cout << " RNDM:: " << alea_.size() << " valeurs aleatoires lues " << endl; 
  rndmst7(seed);
  compteurRndm7_ = 0;
}


void RNDM::rndmst7(unsigned long i)
{
  //  cout << " test of the random generator rndm7 " << endl;

  rndm7_store.i= 0L;
  unsigned long a_coeff;
  unsigned long  c_coeff;
  unsigned long test7[11];

  // 32-bits machine 
#ifndef COMPUTER64b

  test7[0] = 0x3c6ef35f;
  test7[1] = 0x47502932;
  test7[2] = 0xd1ccf6e9;
  test7[3] = 0xaaf95334;
  test7[4] = 0x6252e503;
  test7[5] = 0x9f2ec686;
  test7[6] = 0x57fe6c2d;
  test7[7] = 0xa3d95fa8;
  test7[8] = 0x81fdbee7;
  test7[9] = 0x94f0af1a;
  test7[10] = 0xcbf633b1;

  a_coeff = 1664525L;
  c_coeff = 1013904223L;
  if ( rndm_test7(a_coeff , c_coeff, test7) )
    {
            cout << " random generator successfull test : 32-bits computer " << endl;      
      // following factor is 1/(2.exp(32))
      rndm7_modulo_dividing_factor_ = 0.232830643654e-9;
    }
  else
    {
      cerr << " RNDM::rndmst7 : test for random generator failed, are we really working on a  32-bits computer ? maybe you should active the define COMPUTER64b in (CMT reqirements)  " << endl;
      exit(0);
    }
#else
  test7[0] = 0x1;
  test7[1] = 0x5851f42d4c957f2e;
  test7[2] = 0xc0b18ccf4e252d17;
  test7[3] = 0xcbb5f646404a560c;
  test7[4] = 0xc7033129d2bd141d;
  test7[5] = 0x30705b042917ec1a;
  test7[6] = 0x20fd5db43a776693;
  test7[7] = 0x9a8b7f78da6ef4d8;
  test7[8] = 0x502959d812b031f9;
  test7[9] = 0xab894868b3b04fc6;
  test7[10]= 0x6c0356a743cf3fcf;


  a_coeff = 6364136223846793005L;
  c_coeff = 1L;
  if ( rndm_test7(a_coeff , c_coeff, test7) )
    {
            cout << " random generator successfull test : 64-bits computer " << endl;
      // following factor is 1/(2.exp(64))
      rndm7_modulo_dividing_factor_ = 0.54210108624e-19;
    }
  else
    {
      cerr << " RNDM::rndmst7 : test for random generator failed, are we really working on a  64-bits computer ? maybe you should desactive the define COMPUTER64b (CMT requirements) " << endl;
      exit(0);
    }
#endif
  rndm7_a_coeff_ =  a_coeff;
  rndm7_c_coeff_ = c_coeff;
  rndm7_store.i=i;
}

bool RNDM::rndm_test7(unsigned long a_coeff, unsigned long c_coeff, const unsigned long* test_values)
{
  int k;
  unsigned long test_i = 0;
  bool test = true;
  for (k=0; k< 11; k++)
    {
       test_i =a_coeff* test_i + c_coeff;
       if (test_i != test_values[k])
	 {
	   test = false;
	   printf(" k= %d random value= %lx should be %lx \n", k, test_i, test_values[k]);
	   break;
	 }
    }
  return test;
}

float RNDM::rndm7()
{
  compteurRndm7_++;
  rndm7_store.i=rndm7_a_coeff_*rndm7_store.i+rndm7_c_coeff_;
/* additional factor to ensure rndm7!=1.0 if float */
  return  (float)rndm7_store.i*rndm7_modulo_dividing_factor_*(1.0-RNDM_EPS);
}








