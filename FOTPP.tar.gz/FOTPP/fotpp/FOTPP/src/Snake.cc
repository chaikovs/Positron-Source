// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Snake.cc
 * \brief The Snake class models the trajectory of the particle in the crystal and manage emissions of photons.
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */

#include "Snake.h"
#include "mathematics.h"


#ifdef TEST_WCLASS
//#include "wclass.h"
extern double WCLASS;
#endif

// c p4 - L1MAX (voir REPTIL) est choisi = 0.7 fois la dimension de XL, etc.


const int Snake::_L1MAX=0.7*(_SNAKE_SIZE-1);

Snake::Snake(const RunParameters & rp, ParticleInCrystal & p, PhotonCollection& fcol, const Trigo& tr,  statistiques* stat):  _mature(false),_jzaug(false), _runPar(rp), _part(p),  _trigo(tr), _stat(stat), _photons(fcol) {


  _eloigne = false;

  _ra = -1.0;
  _partIsPositron = _part.isPositron();


  _ancoll = 0.0;

  _dto = 0.0;
	
  _uc = 0.0;

}

Snake::~Snake(){;}

void Snake::cutTale() {
      vector<SnakeStep>* aux = _tete;
      _tete = _queue;
      _queue = aux;

  _tete->clear();
  _tete->push_back(_queue->at(_lpas-1-_l1) );
  _tete->push_back(_queue->at(_lpas - _l1));
  _queue->pop_back();
  _queue->pop_back();


#ifdef DO_STATS
  _stat->incrementMrept();
#endif


  //  _la=_lb;
  _la=_lb - _l1;

  _lpas -= _l1;
  _l1=_lpas-1;
  _lmax=min(_SNAKE_SIZE-1,_l1 + _L1MAX);


  _mature = false;
}
    





// la valeur de retour peut etre 0, 1 ou 2
// 0 : interrompre le traitement de l'evenement
// 1 : emission
// 2 : rien ( pas d'emission, serpent non mur) : on continue
int Snake::makeStepKumakhov(bool migrated,  double PotentialEnergy, double KineticEnergy, double angularMomentum)
{

  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&
  _lpas++;

#ifdef DO_STATS
  _stat->incrementMpas();
#endif

  if (_lpas  == _lmax){
#ifdef DO_STATS
    _stat->incrementNlmax();
#endif
    _mature=true;
  } // [p10]



    SnakeStep bidon;
   _tete->push_back(bidon);
   SnakeStep& aux = _tete->back();

   aux.raz();

  aux.xl = _part.getXPosition();
  aux.yl = _part.getYPosition();
  aux.zl = _part.getZPosition();


  //   premier cut-off angulaire GAMDV2 du kumakhov   [p7]
  double toto=_part.getGamma()*fabs(PotentialEnergy)/ELECTRON_MASS_EV;
  aux.gamdv2 = min(toto,toto*fabs(PotentialEnergy)/(KineticEnergy+1e-9));

  maturation(migrated, PotentialEnergy, KineticEnergy,angularMomentum );
  if ( !_mature ) return 2; 
  else 
    {
      _mature = false;
      _l2 =  _lpas - 1;
      if ( _lpas  != 1 )
	{
	  essais();
	  if (_part.getIexit() ) return 0;
	  else
	    {
	      if ( _part.getIemis() ) return 1;
	      else
		{
		  cutTale(); // [p11a]
		}
	    }
	}
      if (_part.getIexit() ) return 0;
      else return 2;
	
    } // fin mature
}



void Snake::maturation(bool migrated,  double PotentialEnergy, double KineticEnergy, double angularMomentum ){

  if ( _part.getIexit() ) 
    {
      _mature = true;
    }
  //actualise la variable _mature lorsque le serpent est mature EN CAS DE MIGRATION
  if (migrated){
		
    bool jzaugav = _jzaug;
    _jzaug = _part.moduleOfAngularMomentum() < angularMomentum;
    if(jzaugav && !_jzaug) 
      {
	_mature = true;	
      }
  }
	
  double Px = _part.getPx();
  double Py = _part.getPy();
  double r = _part.getRadius();

  bool eloigna = _eloigne;
  _eloigne = r > _ra;
  _ra = r;
  double Et = PotentialEnergy + KineticEnergy;
  bool canalise = (!_partIsPositron)&&(!_eloigne);
  bool lapogee = eloigna && (!_eloigne);
  if (lapogee && canalise)  _mature = true; // [p11]

}


	

bool Snake::initSnake() {

  _vecteur1.clear();
    _vecteur2.clear();

  _queue = &_vecteur1;
    _tete = &_vecteur2;

  //  _tete = _queue;


	
  _l1=0;
  _la=0;
  _lmax = _L1MAX;	
  _lpas=-1;

  _ximin = _runPar.getPhomin()/(_part.getGamma()*ELECTRON_MASS_GEV);

  _umin = _ximin/(1.0 - _ximin);

#ifdef TEST_WCLASS  
  _umin = _ximin; // pour test WCLASS
#endif

  _xmilog = - log (_ximin); 
  _mature = false;
  _jzaug = false;
  _ra = _part.getRadius();	
  _eloigne = false;
  _ancoll = 0.0;

 // si l'electron est trop lent, evenement suivant 	
  return  (_ximin < 0.9999);
}




//C  commande les tirs des photons KUMA et, en cas de reussite,
//C  definit la nouvelle trajectoire  
void Snake::essais()
{
    double poid; 
  double epho;
  double proba;
	
  _part.setIemis(false);
  if ( _l2 <= _l1 )
    {
      cerr << "     essais : ERROR;  L2 <= L1 , l1= " << _l1 << " l2 = " << _l2 << " lpas " << _lpas << endl;
      throw string("poirot");
    }


  //  CALCUL DE LB = FIN DE LA ZONE DE TIR (LA= DEBUT) [es1]

  double sup = -1.0;
  int lessai;
  double pxxl1, pxxl2,pyyl1, pyyl2;
  double distance;
  double pxless, pyless;

//   pxxl1 = XYZ(_l1).px;
//   pxxl2 = XYZ(_l2).px;
//   pyyl1 = XYZ(_l1).py;
//   pyyl2 = XYZ(_l2).py;

  pxxl1 = _tete->at(0).px;
  pxxl2 = _tete->at(_l2 - _l1).px;
  pyyl1 = _tete->at(0).py;
  pyyl2 = _tete->at(_l2 - _l1).py;


  //   for ( lessai = _l1; lessai < _l2; lessai++)
      for ( lessai = 0; lessai < _l2 - _l1; lessai++)
    {
//       pxless = XYZ(lessai).px;
//       pyless = XYZ(lessai).py;

      pxless = _tete->at(lessai).px;
      pyless = _tete->at(lessai).py;

      distance = (pxless - pxxl1) * (pxless - pxxl1) + (pyless - pyyl1) * (pyless - pyyl1);
      distance *= (pxless - pxxl2) * (pxless - pxxl2) +  (pyless - pyyl2) * (pyless - pyyl2);
      if ( distance > sup )
	{
	  sup = distance;
	  //	  	  _lb = lessai;
	  	  _lb = lessai + _l1;
	}
    }       //  [es2]

  if (_part.getIentree() ) _la = 0;
  if (_part.getIexit() ) _lb = _l2;

  if ( _l1 == 0 && !_part.getIexit() ) return; // [es3]

 
  if ( _la > _lb ) 
    {
      cerr << " ERROR :  LA > LB in Snake::essais  " << endl;
      throw string("essais");
    }

  //   CALCUL DE USUP POUR SERPENT        ![es4]
//   XYZ(snakeAbsoluteIndex(0)).ucl = XYZ(snakeAbsoluteIndex(1)).ucl;  // [es5]
  XYZ(0).ucl = XYZ(1).ucl;  // [es5]
  _usup = 0.0;
  for (lessai = _la; lessai < _l1; lessai++) 
    {
      _usup = max(_usup, _queue->at(lessai).ucl);
    }

  for (lessai = 0; lessai <= _lb - _l1; lessai++) 
    {
      _usup = max(_usup, _tete->at(lessai).ucl);
    }


 

  if ( _usup <= _umin )  //  (trajectoire trop douce)
    {
      _part.setIentree(false); 
      return;
    }


  PositionInCell pc = _part.getPositionInCell();

  //  BOUCLE DE TIRAGE

  _xisup = _usup/(1.0 + _usup);

#ifdef TEST_WCLASS
  _xisup = _usup;
#endif



  double h0 = log(_xisup/_ximin)*_runPar.getFrekuma();  // [es6]

  double gamma = _part.getGamma();
  double poimin = _runPar.getPoimin();
  bool newTraj = false;
  //  double Ulocal;
   //   double OX, OY;
   //  int LM;

     SnakeStep  stepLM, stepLMm1;


  for ( lessai = _la; lessai <= _lb; lessai++)
    {

      //   nombre de tirs au point(LESSAI)   [es7]
      double tirs = h0 * XYZ(lessai).dp; // [p18]
      //     (on a enleve /259 en redefinissant FREKUMA)

      double hlocal = mathematics::rndm();

      if ( tirs >= hlocal ) // si tirs < h, on passe au point suivant
	{
	  int ntirs = floor(tirs);
	  tirs -= ntirs;
	  if ( tirs >= hlocal ) ntirs++; // [es7a] 
	  //          - et s'il y a une diffusion a angle >> 1/gamma ???
	  //          - j'essaye d'en tenir compte en prenant DP plutot que CHI
// 	  int IHU = 0; // initialisation (n'importe quelle valeur entre 0 et 10)
// 	  int IHD = 0;

	  _IHU = 0; // initialisation (n'importe quelle valeur entre 0 et 10)
	  _IHD = 0;


	  int ijk;
	  for (ijk = 0; ijk < ntirs; ijk++)
	    {
	      kuma(lessai);

	      proba = max( _AA, 0.0)/_runPar.getFrekuma();
	      epho = gamma * ELECTRON_MASS_GEV * _Ulocal/(1.0 + _Ulocal);


#ifdef TEST_WCLASS
	      epho = gamma * ELECTRON_MASS_GEV * _Ulocal;
#endif


	      //   sttatistiques SUR LES PHOTONS KUMAKHOV:
#ifdef DO_STATS
	      _stat->addEnergyKuma(proba, epho, _IHU, _IHD, _AA);
#endif

#ifndef TEST_WCLASS
	      //   decision aleatoire d'emettre le photon (sous reserve de passer ETAFIN)

	      hlocal = mathematics::rndm();
	      if ( proba >= hlocal * poimin )    // [es10]
		{

		  //   position initiale pour la nouvelle trajectoire 
 		  
		  //  "derapage"   [ef3]
		  stepLM = XYZ(_LM);
		  stepLMm1 = XYZ(_LM - 1);

// 		  double dpx = XYZ(_LM).px - XYZ(_LM - 1).px;
// 		  double dpy = XYZ(_LM).py - XYZ(_LM-1).py;
// 		  double toto = 0.5* XYZ(_LM).dtau * _Ulocal * _GM /(dpx*dpx + dpy*dpy);
// 		  _part.derapeXY( XYZ(_LM).xl + toto*dpx, XYZ(_LM).yl + toto*dpy ); // [ef3]

		  double dpx = stepLM.px - stepLMm1.px;
		  double dpy = stepLM.py - stepLMm1.py;
		  double toto = 0.5* stepLM.dtau * _Ulocal * _GM /(dpx*dpx + dpy*dpy);
		  _part.derapeXY( stepLM.xl + toto*dpx, stepLM.yl + toto*dpy ); // [ef3]

		  //   condition de non-migration [ef4]
		  _part.setIemis(!_part.anyMigration());
		  //Modification de MIGGG
		  //		  _part.setBigJump(false); //  (si on veut continuer malgre un MIGGG)
	      
		  //       cas ETAFIN reussi
		  if ( _part.getIemis() ) 
		    {
		      //            enregistrement du photon 
		      double thetx = _OX / gamma;
		      double thety = _OY / gamma;
		      poid = max( proba, poimin);    // [es10]
		      _photons.fill(epho, thetx, thety, _part.getXPosition(), _part.getYPosition(), _part.getZPosition(), poid);
#ifdef DO_STATS
		      _stat->incrementMfot();
#endif			
		      //            decision de prendre la nouvelle trajectoire [es10]
		      if ( proba > hlocal)   // decide oui 
			{
			  newTraj = true;
			  break;
			}
		    }
#ifdef DO_STATS
		  else // cas ETAFIN rate - a supprimer si ca n'arrive presque jamais ???
		    {
		      poid = max( proba, poimin);    // [es10]
		      _stat->incrementAvort(poid, epho);
		    }
#endif
		}
#endif
	    } // fin boucle ijk (etiq. fortran 52)
	  if ( newTraj ) break;



 	} // fin if tirs
    } // fin lessai

  if (!newTraj ) 
    {
      //  cas ou il n'y a pas de photons emis - du moins, cas ou on ne modifie
      //  pas la trajectoire (aucun photon avec POID > 1.)
      _part.setIemis(false);
      _part.setIentree(false);
      //        rappel de X,Y sauvegardes (efface le derapage)
      _part.reIniCoorAndCell(pc);
    }
  else // Le photon est enregistre ET on modifie la trajectoire
    {
//       _part.setZ(XYZ(_LM).zl);
//       _part.setIentree(false);
//       //    nouvelle energie-impulsion   [ef2]
//       _part.setEnergyMomentum(XYZ(_LM).px - _OX*_Ulocal/(1.0 + _Ulocal),
// 			      XYZ(_LM).py - _OY*_Ulocal/(1.0 + _Ulocal),
// 			      gamma/(1.0 + _Ulocal));

      _part.setZ(stepLM.zl);
      _part.setIentree(false);
      //    nouvelle energie-impulsion   [ef2]
      _part.setEnergyMomentum(stepLM.px - _OX*_Ulocal/(1.0 + _Ulocal),
			      stepLM.py - _OY*_Ulocal/(1.0 + _Ulocal),
			      gamma/(1.0 + _Ulocal));
		
		
#ifdef DO_STATS
      _stat->addPhotKuma(proba, epho);
#endif
    }
}






// C  TIRE AU HASARD L'IMPULSION DU PHOTON,
// C  CALCULE L'AMPLITUDE AU CARRE D'EMISSION DU PHOTON.
// void Snake::kuma(int lessai, double & U, double& OX, double& OY,double& AA,  int& LM, double& GM, int& IHU, int& IHD)
void Snake::kuma(int lessai)
{

  //   try
  //     {
  vector<double> alocal(6,0.0);
  int tailleGat = _l2 + 1;
  //  cout << " begin " << _snakeBegin << " l1 = " << _l1 << " l2= " << _l2 << " tailleGat = " << tailleGat << endl;
//   vector<double> gatx(tailleGat);
//   vector<double> gaty(tailleGat);
//   vector<double> glocal(tailleGat);

  _gaga.resize(tailleGat);



  
  int long_trigo = _trigo.getDimension();

  double phi = 0.0;
  double aux;



  //   1. tirage de l'energie et de l'angle du photon   [k1]

  //  TIRAGE  DE  U= hbar*OMEGA/(E-hbar*OMEGA)
  double h = mathematics::rndm();
  double xi = _ximin*pow(_xisup/_ximin, h);
  _Ulocal = xi/(1.0 - xi);

#ifdef TEST_WCLASS
  _Ulocal = xi;
#endif

  if ( _Ulocal > XYZ(lessai).ucl ) // [k2]
    {
      _AA  = 0.0;
      return;
    }

#ifdef DO_STATS
  _stat->incrementNkuma();
#endif

#ifdef TEST_WCLASS
  double xmax = XYZ(lessai).ucl;
#else
  // ici MODIF DE MAI 2010
  double xmax = XYZ(lessai).ucl/(XYZ(lessai).ucl + 1.0);
#endif
  xmax = min(xmax, _xisup);
  double hprime = h * log(_xisup/_ximin)/ log(xmax/_ximin);
  _IHU = floor( 10.0 * hprime);

  //  TIRAGE DE LA DIRECTION (OX,OY) DU PHOTON

  double dlta02 = pow( _usup/(100.0 * _Ulocal), 0.67);    // [k3] 
  // 0.67 : 2/3, valeur theorique (voir documentation [k3] )
  dlta02 = min( dlta02, XYZ(lessai).gamdv2) + 1.0; // [k3a]

  h = mathematics::rndm();
  _IHD = floor(10.0 * h); //  POUR EFFIC

  double gat = dlta02 * ( 1.0/h - 1.0 );
  gat = sqrt( gat );

  int k = floor ( mathematics::rndm() * (double)long_trigo );

  _OX = XYZ(lessai).px - gat * _trigo.getCosw(k);
  _OY = XYZ(lessai).py - gat * _trigo.getSinw(k);


  //   2. CALCUL DE LA PROBABILITE D'EMISSION     [k4]

  double omegag = _Ulocal * MC_OVER_HBAR/(8.0*PI);

  // C   PREPARATION . LIMITES D'INTEGRATION LU,LV [k6],
  // c   POINT D'EMISSION LM,
  // c   FACTEUR NORMALISANT DENOR [k,k7].

  //  double denor = 0.0;
  double fsg2ma = 0.0;

  //   tabulation de GATX,GATX,G, recherche des bornes d'integration LU,LV
  int lu, lv;
  double fsg2;
  double fsg2mi = 1.0e30; // infinity
  int ll;

  lu = computeLUV(0, 0, 0, _l1-1, _queue, fsg2, fsg2mi);
  lu = computeLUV(lu, _l1, 0, 0, _tete, fsg2, fsg2mi);



   //   - recherche de LV
   lv = _l1;
   fsg2mi = fsg2;




   lv = computeLUV(lv, _l1,  1, _l2 - _l1, _tete, fsg2, fsg2mi);


  double denor =  computeNormalizingFactor(dlta02);


  if (_part.getIentree() ) lu = 0;

  if (_part.getIexit() ) lv = _l2;



  if ( lu == lv ) 
    {
      _AA = 0.0;
      return;
    }

  if ( denor == 0.0 ) 
    {
      cerr << " KUMA : ERREUR denor = 0  "  << endl;
      //     cerr << " lessai= " << lessai <<  " lu= " << lu << " lm= " << _LM <<  " lv= " << lv << " l= " << l   << endl;
 //           cerr << " denor= " << denor << " g(l)= " <<   _gaga.at(snakeRelativeIndex(l)).g << endl;
 //         cerr << " denor= " << denor << " g(l)= " <<   _gaga.at(l).g << endl;
	   //    cerr << " denor= " << denor << " g(l)= " <<   glocal.at(l) << endl;
      int kk;
      cerr << " DTAU " ;
      //      for (kk = 0; kk <= _l2; kk++) cerr << " " << XYZ(l).dtau;
      cerr << endl;
      throw string("poirot");
    }

  //   FIN DE LA PREPARATION;INTEGRATION

//   double vtau = 1.0/_gaga.at(snakeRelativeIndex(lu)).g;
  double vtau = 1.0/_gaga.at(lu).g;
//   double vx = _gaga.at(snakeRelativeIndex(lu)).gatx * vtau; // vitesse apparente   [k8]
//   double vy = _gaga.at(snakeRelativeIndex(lu)).gaty * vtau; 
  double vx = _gaga.at(lu).gatx * vtau; // vitesse apparente   [k8]
  double vy = _gaga.at(lu).gaty * vtau; 


  double slocal = 0.0; // initialisations
  double clocal = 1.0; 
  double wlocal = 0.0; 
  double bsup = 0.0;

  //   boucle d'integration de l'amplitude
  int l;

 //  for ( l = lu + 1; l < _l1; l++)
//     {
//       cumuleIntegrale( l, omegag, _queue->at(l), slocal, clocal, wlocal, bsup, vtau, vx, vy, phi, alocal );

//     } 

//   for ( l = 0 ; l <= lv - _l1; l++)
//     {
//       cumuleIntegrale( l + _l1, omegag, _tete->at(l), slocal, clocal, wlocal, bsup, vtau, vx, vy, phi, alocal );

//     } // fin de l'integration


  for ( l = lu + 1; l <= lv; l++)
    {
      int indexGaga = l;
      //cumuleIntegrale( indexGaga, omegag, XYZ(l), slocal, clocal, wlocal, bsup, vtau, vx, vy, phi, alocal );

      SnakeStep& snkst = XYZ(l);
      double dw = (_gaga.at(indexGaga).g + _gaga.at(indexGaga-1).g) * snkst.dtau * omegag; // phase [k9]
     if ( dw == 0.0 ) 
	{
	  cerr << " KUMA : ERREUR dw = 0 " << endl;
	  //	  cerr << " lessai= " << lessai <<  " lu= " << lu << " lm= " << _LM <<  " lv= " << lv << " l= " << l   << endl;
// 	  	  cerr << " denor= " << denor << " g(l)= " <<   _gaga.at(snakeRelativeIndex(l)).g << " dw= " << dw << endl;
//	  	  cerr << " denor= " << denor << " g(l)= " <<   _gaga.at(l).g << " dw= " << dw << endl;
		  //	  cerr << " denor= " << denor << " g(l)= " <<   glocal.at(l) << " dw= " << dw << endl;
	  int kk;
	  cerr << " DTAU " ;
	  for (kk = 0; kk <= _l2; kk++) cerr << " " << snkst.dtau;
	  cerr << endl;
	  throw string("poirot");	      
	}

      wlocal += dw;
      double wwlocal = (double)_trigo.getDimension() * (wlocal - floor(wlocal) );
      int iww = floor (wwlocal);
      wwlocal = ( wwlocal - iww) * _trigo.getTanw0();
      double ca = clocal;
      double sa = slocal;
      
      clocal = _trigo.getCosw(iww) - _trigo.getSinw(iww) * wwlocal;
      slocal = _trigo.getSinw(iww) + _trigo.getCosw(iww) * wwlocal;

      //       calcul des cosinus et sinus moyens    [k10]
      double cm, sm;
      if ( dw > 1.0e-3 ) 
	{
	  cm = ( slocal - sa) /dw;
	  sm = ( ca - clocal) / dw;  // [k11]
	}
      else
	{
	  cm = PI * (clocal + ca);
	  sm = PI * (slocal + sa);  //  [k12]
	}
      double vtaua = vtau; // antecedents
      double vxa = vx;
      double vya = vy;

      vtau = 1.0/_gaga.at(indexGaga).g; 
      vx = _gaga.at(indexGaga).gatx * vtau; 
      vy = _gaga.at(indexGaga).gaty * vtau; 


      double dvx = vx - vxa; // accroissements
      double dvy = vy - vya;
      double dvtau = vtau - vtaua;

      //       recherche du point d'emission
      double aux = max( vtaua, vtau);
      double blocal = max(  snkst.dp, snkst.chic*snkst.dtau) * aux * aux;
      if ( blocal > bsup ) 
	{
	  bsup = blocal;
	  _LM = indexGaga;
	  phi = wlocal;
	} // [k14]

      alocal[0] += cm * dvx;
      alocal[1] += sm * dvx;
      alocal[2] += cm * dvy;
      alocal[3] += sm * dvy;
      alocal[4] += cm * dvtau;
      alocal[5] += sm * dvtau;

    } // fin de la boucle d'integration

  double a0 = alocal[0];
  double a1 = alocal[1];
  double a2 = alocal[2];
  double a3 = alocal[3];
  double a4 = alocal[4];
  double a5 = alocal[5];

  _AA = a0*a0 + a1*a1 + a2*a2 + a3*a3;
  _AA *=  1.0 + (1.0 + _Ulocal)*(1.0 + _Ulocal);
  _AA += _Ulocal * _Ulocal * (  a4*a4 + a5*a5 );


   _AA /= (1.0 + _Ulocal)*(1.0 + _Ulocal) * denor * dlta02 * EIGHT_PI_CUB_OV_ALPHA;



//      _GM = _gaga.at(snakeRelativeIndex(_LM)).g;
     _GM = _gaga.at(_LM).g;




#ifdef TEST_WCLASS
  _AA = 2.0 * ( alocal[0] * alocal[0] + alocal[1] * alocal[1] + alocal[2] * alocal[2] + alocal[3] * alocal[4] );
_AA /= denor * dlta02 * EIGHT_PI_CUB_OV_ALPHA;
#endif

  //   REJET POUR PHASE DEBILE ?
 phi -= _GM * XYZ(_LM).dtau * omegag;

  if ( phi < 0.08 && !_part.getIentree() ) _AA = - _AA;
  phi = wlocal - phi;
  if ( phi < 0.08 && !_part.getIexit() ) _AA = - _AA;   // [k15]


}





// C p7 -----------------------------------------------------------    
// c   GAMDV2 = (gamma*angle typique de deflection)**2 au cours d'une 
// c   ondulation de la trajectoire.
// c   Cet "angle typique" est inferieur a - ou de l'ordre de l'angle de Lindhard.
// c   On admettra que c'est un cut-off angulaire pour KUMA


// c p10 ---------------------------------------------------------------
// C    Voir REPTIL; Si trop frequent, augmenter la dim. de XL, etc.
// C    On doit avoir NLMAX << NREPT


// C p11 ------------------------------------------------------------------
// C     Cas canalise: Le serpent est MATURE si la distance a l'axe le + proche
// C     VIENT DE PASSER par un maximum. 
// C     Cas non canalise: voir MIGRE


// c p11a  - LE SERPENT N'EST PAS MUR OU LES ESSAIS KUMA ONT ECHOUE


// c p18 - le nombre de photons par pas est estime a priori a |dp|
// c      Cette quantite interviendra dans la facteur DENOR de ESSAI et KUMA,
// c      ainsi que dans la recherche du "point d'emission" de KUMA.
// c      La version ancienne utilisait chi*dtau (d'apres Landau "QED" par.90)


// c ------------------------------------------------------------------------
// C LABEL DES POINTS DU SERPENT AVANT ET APRES REPTIL:
// C                      
// C   0             LA           L1            LB                L2   L(=LPAS ??
// C   .  .  .  . .  .  .  . . .  .  .  . . .   .  .  . .  .  .   .    .
// C                              0             LA                L1   L(=LPAS ??
// c ------------------------------------------------------------------------


// c es1 ------------------------------         
// C   Je veux que LB soit loin a la fois de L1 et de L2 dans l'espace
// C   des vitesses transverses (Idem pour LA,L0,L1, grace a REPTIL).

// c es2 ----------------------------
// C   LB entre L1+1 ET L2-1. Apres REPTIL : LA entre 1 ET L1-1,
// C   sauf SORTIE (LB=L2) , ENTREE (LA=0) , ou cas rare L2-L1=1

// c es3 - cas ou le serpent n'a qu'une revolution.

// c es4 - USUP est un cut-off global pour l'intervalle [LA,LB]
// c      On tiendra compte du cut-off local dans KUMA [k2]

// c es5 -----------------------------------
// C  MOTIF: A L'INITIALISATION D'UN NOUVEAU SERPENT, DT EST PRIS A PEU
// C  PRES NUL, D'OU UCL(0) EXAGEREMENT GRAND

// c es6 -  FREKUMA trop grand: programme trop lent
// C        FREKUMA trop petit: beaucoup de photons oublies (PROBA >1)

// c es7 - Un essai a chaque pas serait trop long. 
// c       Si on ignore la diffusion multiple, le nombre moyen "TIRS" 
// c       de tirs effectues au pas(LPAS) est proportionnel a la
// c       longueur du pas DTAU et a la valeur locale de CHI.
// c  Avec la diff. mul. on le generalise CHI*DTAU par DP(LESSAI)/259.
// c  (le facteur 259 etant omis, on a divise l'ancien FREKUMA par 259)  
// c  On tient compte de ce nombre moyen d'essais par le facteur DENOR dans KUMA

// c es7a - Le nombre (entier) de tirs realises, NTIR, est choisi au hazard:
// c  - soit l'entier juste au dessus, avec la probabilite = partie frac.(TIRS)
// c  - soit l'entier juste en dessous, avec la probabilite complementaire.
      


// c es10 - simulation normale : POIMIN = 1.  
// c       simulation forcee  : POIMIN < 1  (pour cible mince). Dans ce cas
// c       on enregistre plus de photons.
// c       Cependant on ne leur attribue qu'un POID normal,
// c       et on ne modifie la trajectoire que si le photon aurait ete accepte
// c       en simulation normale.  Voir [p2]



// c - NOTES/ETAFIN ---------------------------------------------------------

// c  e.f.1  On fait un retour en arriere au "point d'emission"
// c         LM defini dans KUMA pour initier la nouvelle trajectoire.
// c         (On devrait en principe aussi reprendre les X0CELL et Y0CELL
// c         correspondants, mais nous ne les avons pas gardes en memoire)  

// c  e.f.2  Dans le cas ou il n'y a pas de diffusion multiple,
// c         on suppose la conservation de l'impulsion dans le processus
// c         electron --> electron + photon. Ceci est fait dans ESSAI  

// c  e.f.3. La conservation de l'energie-impulsion est impossible 
// c         pour le processus electron --> electron + photon en l'absence
// c         de champ exterieur. Dans le champ cristalin,  elle est possible 
// c         si l'electron descend dans le potentiel d'une denivelee 
// c         = m_e * GM * U/(2*GAMMA)
// c         Ce "derapage" est de nature quantique, mais, pour un grand nombre
// c         de photons mous, le cumul des derapages equivaut a la force 
// c         d'Abraham-Lorentz. 
// c         Dans le cas ou il y a diffusion multiple, le derapage n'est pas
// c         necessaire, car il peut y avoir transfert d'impulsion longitudinal.
// c         La recette adoptee tient compte du premier cas et donne un derapage
// c         negligable dans le second.

// c  e.f.4  le derapage ne doit pas faire changer de cellule. 
// c         S'il y a changement (MIG), le photon est avorte.


// c k1 ------------------------------------------------------
// C   XI=(energie du photon)/(energie initiale de l'electron).
// C    U=(energie du photon)/(energie FINALE de l'electron).
// c   (OX,OY) = GAMMA*(angle du photon avec l'axe).
// c
// C   On tire U,OX,OY selon la distribution 
// c      1/B *dU/U /PI *
// C      d(GATX)/DELTA0 * idem(Y) /(1+(GAT/DELTA0)**2)**2.
// c
// c   GATX=PX-OX ; idem pour GATY.
// c   GAT = GAMMA*(angle du photon avec la trajectoire) 

// C   la deuxieme ligne = d2(GAT) * DELTA0**2 /(DELTA0**2+GAT**2)**2)
// C   il faudra donc multiplier AA par PI/DELTA0**2 * ???
// c
// c   DELTA0 superieur a 1. Dans le programme, on utilisera la variable
// c   DLTA02 = DELTA0**2

// c k2 - ici on limite U au cutoff local 

// c k3  - Justification : les photons de U << CHI ont un angle moyen
// c       plus grand que 1/gamma. 
// C   - Un grand coef.num. apres "USUP/U/" remplit le tableau d'efficacite
// c     en bas a gauche au detriment d'en haut a gauche. Idem pour un grand
// c     exposant.
// c     Valeur suggeree pour le coef.num. : 50 ??? 100 ???
// c     Valeur theorique de l'exposant: 2/3 (en champ uniforme)

// c k3a -------------------------------------------------
// c     justification:  le cut-off angulaire est donne
// c     - soit par la formule precedente [k3], valable en champ uniforme
// c     - soit par GAMDV2(LESSAI), celui-ci correspondant a un angle de 
// c     deflection typique [p7].
// c     On prend le plus petit des deux cut-off.
// c     On rajoute + 1. a DLTA02 pour que cet angle soit au moins egal a 1/gamma.

// c k4 -------------------------------------------
// C   d(PROBA)=1/(137*8PI2) * d3K/K * ((1+(P/P')**2) * |"t.f.(GAT)"|^2
// C   +U**2 * |"t.f.(1)"|^2 )
// C   "t.f.(GAT)" OU "t.f.(1)" =SOMME dTAU *(GAT OU 1) * EXP(I*Phase)
// C   d3K/K=U*dU/(1+U)**3 * M(ELEC)**2 * dOX * dOY
// C   d(PROBA)=dU/U *dOX*dOY * AA(CALCULE ICI)
// C   d(A(1 A 4)=d(dX/dZETA) * d(COS OU SIN)/d(Phase)
// C   d(A(5 OU 6)=d(dTAU/dZETA) * d(COS OU SIN)/d(Phase)
// C   dZETA=2*GAMMA*d(temps apparent)=(1+GAT**2)*dTAU
// C   d(Phase)=OMEGA*(GAMMA1/GAMMA2)*d(temps apparent)=U*dZETA*M/2
// C   W=Phase/2PI. Il faut donc diviser A(1 A 6) par 2PI, soit AA par (2PI)

// c k4a    G = GAT**2 + 1 
// c        DLTA02+G(L)-1.D0 = DELTA0**2+GAT**2   (voir note k1 pour DLTA02)
       
// c k5 - voir "tirage de l'energie et de l'angle" dans KUMA  
// c      et la "BOUCLE DE TIRAGE" dans ESSAI.

// c k6 -----------------------------------------
// C    le debut de l'integration (LU) correspond a un minimum de F/G**2
// C    En gros c'est un minimum de l'acceleration transverse apparente
// c    (avec le "temps" ZETA). Idem pour la fin de l'integration (LV).

// C k7   DENOR # somme sur L appartenant a [LA,LB] de densite de tir dans
// c      l'espace (U,OX,OY). Cette densite est # a DP(L) [es7]
// c      fois une fonction de OX,OY [k1] fois une fonction de U [k2]

// c k8 ---------------------------------------------
// c     VTAU: dTAU/dZETA
// c     VX:(dX-OX*dTAU)/dZETA
// c     VY:(dY-OY*dTAU)/dZETA
// C     ou dZETA=2*GAMMA*(T-Z)

// c k9 -----------------------------------      
// C     d(Phase)=0.5*M*U*G*dTAU ;   W = phase * 1024
// c   On prend comme G la moyenne de G(L) et G(L-1)

// c k10 - CM = 2PI* [moyenne du cosinus pendant dTAU(L)]

// c k11 - precision relative: 2.D-8/(2PI*dW)  < 3.E-6

// c k12 - erreur relative: (PI*dW)**2 /3 < 3.E-6 

// c k13 - coef.num. 33983. = 137*8*PI**3

// c k14 - on choisit le point d'emission a un maximum de dP/G^2,
// c       en principe. Toutefois, si dP provient d'une diffusion multiple,
// c       on le compare a l'action F*T du champ continu pendant le temps T 
// c       ou "l'acceleration apparente" est constante. 
// c       T = (environ) dT * coef.num.DABS(F) --> F*T = CHIC*dTAU (cf.p14)      

// c k15 ----------------------------------------
// C   On demande une variation de phase d'au moins 0.08 (*2 PI) 
// c   pour eliminer la divergence infrarouge. Ce parametre 0.08 a ete fixe
// c   par une regle de somme.
