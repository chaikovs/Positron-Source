// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Fot.h
 * \brief The Fot class implements the phenomenon of channeling
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */


#ifndef _FOT_H
#define _FOT_H

#include <iostream>
#include <math.h>

#include "Particle.h"
//#include "Photon.h"
#include "Snake.h"
#include "Crystal.h"
#include "Lindhard.h"
#include "ParticleCollection.h"
#include "RunParameters.h"
//#include "Bremsstrahlung.h"
#include "Trigo.h"
#include "statistiques.h"

#ifdef TEST_WCLASS
extern double WCLASS;
#endif

using namespace std;


/** \class Fot
 *
 *  drives the fot algorithm
 */
class Fot {
 private:


  PhotonCollection _photons;
  Snake* _snak;
  ParticleInCrystal* _partCrys;
  Lindhard _lind;
  Trigo _trigo;
  statistiques* _stat;
  const RunParameters& _runPar;

       double _etmax, _vtmax, _zexit;


  int _nevnt;


 public:

  /**
   *  \brief Constructor
   *
   *  Construct the Fot object from data 
   *
   *  \param RunParameters& : parameters concerning the crystal and the Kuma photon
   *
   */
  Fot(RunParameters& rp);
	
	
  /**
   *  \brief Destructor
   *
   *  Destroy the Fot object
   *
   *
   */
  ~Fot();

	
  /**
   *  \brief Main method where the algorithm of channeling is implemented
   *
   *  Main method where the algorithm of channeling is implemented
   *
   */
  //   void make();
  void makeKumakhov(ParticleCollection& partColl);

  const ParticleInCrystal& makeSingleParticleKumakhov(const Particle* part);

  void poirot();


  const PhotonCollection& getPhotonCollection() const
  {
    return _photons;
  }

  void finir() 
  {
    cout << " end of the bunch " << endl;
    cout << " number of events " << _nevnt << endl;
#ifdef TEST_WCLASS
      double gamma = _partCrys->getGamma();
      WCLASS *= gamma* gamma *0.96e-8;  //  cas du test "W classique"  ![p19]
      cout << "  Wclassique " << WCLASS << endl;
#endif
    cout << endl;
#ifdef DO_STATS
    _stat->tsatis();
#endif
  }
};




#endif
