// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file PosiitonInCell.h
 * \brief a pair of coor. (X,Y) in Cell (X0Cell, Y0Cell) 
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */


#ifndef _POSITIONINCELL_H
#define _POSITIONINCELL_H

/** \struct  PositionInCell
 *
 *  a pair of coor. (X,Y) in Cell (X0Cell, Y0Cell) 
 */

typedef struct  {
  double x,y;
  double xCell, yCell;
  bool migrated;
  bool bigJump;
  void set(double xx, double yy, double xc, double yc)
  {
    x = xx;
    y = yy;
    xCell = xc;
    yCell = yc;
    migrated = false;
    bigJump = false;
  }
} PositionInCell;

#endif
