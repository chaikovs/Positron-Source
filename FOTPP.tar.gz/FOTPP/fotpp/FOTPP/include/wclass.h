#ifndef WCLASS_H
#define WCLASS_H

double WCLASS;



#endif
