// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Photon.h
 * \brief The Photon class creates a photon with a predifined specifications
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */


#ifndef _PHOTON_H
#define _PHOTON_H

#include <iostream>




using namespace std;


/** \class  Photon
 *
 *  The Photon class is the object that will contain all data concerning the photon
 */
class Photon {
  private:
    double _ephot;

    double _thetax;

    double _thetay;


    double _xemis, _yemis;
    double _zemis;

    double _poids;


  public:
	
	
	/**
     *  \brief Constructor
     *
     *  Default constructor of the photon
     *
     */
    Photon();

	
	/**
     *  \brief Destructor
     *
     *  Destroy the photon 
     *
     *
     */
    ~Photon();

	
	/**
     *  \brief Constructor
     *
     *  Construct the photon from data 
     *
     *  \param double :
	 *  \param double : X photon emission angle
	 *  \param double : Y photon emission angle
	 *  \param double : Z position of the photon emission
	 *  \param double : weight of the photon
     *
     */
    Photon(double e, double tx, double ty, double x, double y,double z, double p);	
	


    double getEnergy() const 
    {
      return _ephot;
    }


    double getXemis() const 
    {
      return _xemis;
    }

    double getYemis() const 
    {
      return _yemis;
    }

    double getZemis() const 
    {
      return _zemis;
    }

    double getThetax() const
    {
      return _thetax;
    }

    double getThetay() const
    {
      return _thetay;
    }

    double getWeight() const
    {
      return _poids;
    }


	/**
     *  \brief Stock data of the photon
     *
     *  Stock data of the photon in a variable
     *
     * \return bool: return data concerning the photon
     */
	string  outputFlow() const;

	
	/**
     *  \brief Print the photon
     *
     *  Edit data concerning the photon 
	 *
     */
	void print() const;
};
#endif
