// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file mathematics.h
 * \brief The mathematics class provides static mathematical functions
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */


#ifndef _MATHEMATICS_H
#define _MATHEMATICS_H
#include "rndm.h"
#include "GlobalConstants.h"

#include <iostream>
#include <math.h>


using namespace std;


/** \class mathematics
 *
 *  The mathematics class provides mathematical functions (in particular a random generator)
 */
class mathematics 
{


 private:

  static  RNDM _alea;

 public:

  static double rndm()
  {
    return _alea.rndm();
  } 

  static  RNDM* getRandomGenerator() 
  {
    return &_alea;
  }
	
	/**
     *  \brief the Gaussian formula
     *
     *  Calculate the Gaussian
     *
     * \return double: the Gaussian value
     */


static double gauss( double xm, double s ){
	
  double x1 = mathematics::rndm();
  double x2 = mathematics::rndm();
	
	
	double g = xm + s * sqrt (-2 * log(x1)) *  cos(PI * x2 * 2.0);
	
	return g;
}
	

};

#endif
