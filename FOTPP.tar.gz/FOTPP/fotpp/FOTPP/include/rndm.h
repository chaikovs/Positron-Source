// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file rndm.h
 * \brief random generator
 * \author Guy LE MEUR (from guineapig, Daniel Schulte, CERN)
 * \date 01.09.2010
 */
#ifndef RNDM_SEEN
#define RNDM_SEEN



#define RNDM_EPS 6e-8

#include <vector>
using namespace std;



class RNDM
{


  int nalea_;
  int suivant_;
  vector<float> alea_;


  int compteurRndm7_;
  unsigned long rndm7_a_coeff_, rndm7_c_coeff_;
  float rndm7_modulo_dividing_factor_;


 struct
{
  //  unsigned int i;
  unsigned long i;
  float scal;
  unsigned int n;
} rndm7_store;




void rndmst7(unsigned long i);
bool rndm_test7(unsigned long a_coeff, unsigned long c_coeff, const unsigned long* test_values);

float rndm7();



public:


 RNDM();

 RNDM(unsigned long seed);

void init(unsigned long seed = 1);



inline float rndm() 
{

/*   if ( suivant_ >= alea_.size() ) */
/*     { */
/*       cerr << " serie aleatoire epuisee " << endl; */
/* 	exit(0); */
/*     } */
/*   return alea_[suivant_++]; */
       return rndm7();

}

};
#endif
