// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Evenement.h
 * \brief The Evenement class implements the treatment of a single particle
 * \author Guy LE MEUR 
 * \date 01.09.2010
 */
#ifndef _EVENEMENT_H
#define _EVENEMENT_H

#include "Particle.h"
#include "Photon.h"
#include "Snake.h"
#include "Bremsstrahlung.h"
#include "Crystal.h"
#include "Lindhard.h"

#include <iostream>
#include <math.h>
#include "statistiques.h"


/** \class Evenement
 *
 *  The Evenement class implements the treatment of a single particle
 */

class Evenement 
{

const RunParameters* _runPar;
    ParticleInCrystal* _partCrys;
  Snake* _snak;
  BremsStrahlung* _bremse;
PhotonCollection* _photons;


  double _Zexit;

   double _vtmax;
   double _etmax;

  double _pt2max;

  double _vt, _ecin, _dtinv1, _dtinv2, _gamma;

 bool _restartSnake;

 double _zj;

 public :


 Evenement( Snake* snak, BremsStrahlung* brms, PhotonCollection* photons, double etmax, double vtmax, double Zexit);

 ~Evenement();


 bool reInitSnake();


 bool makeStep();


 private : 
};


#endif
