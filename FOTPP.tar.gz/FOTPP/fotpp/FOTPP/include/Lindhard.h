// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Lindhard.h
 * \brief The Lindhard structure provides potentials and Lindhard force
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */


#ifndef _LINDHARD_H
#define _LINDHARD_H

// C   DCOLL,DCOLTA: inverse du libre parcours moyen de diff. incoherente.


/** \struct  Lindhard
 *
 *  provides potentials and Lindhard force
 */
typedef struct  {
    double _epot;
	
	double _f;

    double _fx;

    double _fy;

    double _dcoll;

} Lindhard;
#endif
