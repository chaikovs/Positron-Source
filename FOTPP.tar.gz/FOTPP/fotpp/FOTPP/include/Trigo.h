// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file Trigo.h
 * \brief The Trigo class provides a tabulation of the functions cosinus and sinus
 * \author Guy LE MEUR & Sandrine BERTE
 * \date 01.09.2010
 */


#ifndef _TRIGO_H
#define _TRIGO_H




#include <iostream>
#include <vector>
#include <math.h>

#include "Crystal.h"
#include "GlobalConstants.h"

using namespace std;


/** \class  Trigo
 *
 *  The Trigo class provides the cosinus and sinus for each step
 */
class Trigo {
	
private:

  static const int _LONG_TRIGO = 1024;

	
	vector<double> _cosw;
	vector<double> _sinw;
	double _tanw0;

 public:
	
	Trigo();
	//	Trigo(int long_tab);
	
	
	/**
     *  \brief return the value of cosinus
     *
     *  Allows access to the value of cosinus at the step k
     *
     * \return double: return the value of cosinus
     */
	double getCosw(int k) const;

	
	/**
     *  \brief return the value of sinus
     *
     *  Allows access to the value of sinus at the step k
     *
     * \return double: return the value of sinus
     */
	double getSinw(int k) const;

	
	/**
     *  \brief return the value of tan
     *
     *  Allows access to the value of tan
     *
     * \return double: return the value of tan
     */
	double getTanw0() const;

	
	/**
     *  \brief return the dimension of vectors
     *
     *  Allows access to the dimension of vectors
     *
     * \return double: return the dimension of vectors
     */
	double getDimension() const;


};

#endif
