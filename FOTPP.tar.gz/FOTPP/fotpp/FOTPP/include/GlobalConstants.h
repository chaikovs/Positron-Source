// ********************************************************************
// *                                                                  *
// * The FOTPP sotware is copyright of the LAL- Orsay- France         *
// *------------------------------------------------------------------*
// * FOTPP is a object oriented (C++) version of FOT, a simulation    *
// * code for channeling radiation by ultrarelativistic electrons or  *
// * positrons originally developed by X. Artru                       *
// * ( x.artru@ipnl.in2p3.fr) ; NIM, B48 (1990) 278-282               *
// *                                                                  *
// * developpers of FOTPP :                                           *         
// * Guy Le Meur (lemeur@lal.in2p3.fr),                               *
// * Sandrine Berte (internship at LAL)                               *
// * Francois Touze (touze@lal.in2p3.fr)                              *
// *                                                                  *
// * Contributor (implementation in GEANT4) :                         *
// * Olivier Dadoun  (dadoun@lal.in2p3.fr)                            *
// ********************************************************************
//------------------------------------------------------------------
/**
 * \file GlobalConstants.h
 * \brief The file GlobalConstants.h contains the definitions of global mathematical and physical constants
 * \author Guy LE MEUR 
 * \date 01.09.2010
 */
#ifndef _GOBALCONSTANTS_H
#define _GOBALCONSTANTS_H


#define PI 3.14159265
#define SQROOT3 1.73205080757
#define CST_BIZARRE 0.03887 // (voir [b4], depend de cst d'Euler
#define EM_ALPHA 1.0/137.
#define EIGHT_PI_CUB_OV_ALPHA 33983.
#define ALPHA_OV_PI 0.0023228
#define ELECTRON_MASS_GEV .510999e-3
#define ELECTRON_MASS_EV  510999.
#define FACTOR_THOMAS_FERMI 0.8853
#define RBOHR1 0.529
#define EULER 0.5772
#define PI_4_HBAR_ALPHA 181.
#define PI_4_ALPHA_SQ 6.695e-4
#define MC_OVER_HBAR  259.0 // mc/hbar, inverse compton wavelenght (Angstrom ^-1
#define DR_LINDHARD 0.0025  // pas de discretisation pour calcul pot. lindhard

#define CONSTANT_p15 0.0243 // ????? 
#define MAX_PHOTONS 512
#endif
