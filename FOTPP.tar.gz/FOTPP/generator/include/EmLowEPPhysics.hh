#ifndef EmLowEPPhysics_h
#define EmLowEPPhysics_h 1

#include "G4VPhysicsConstructor.hh"
#include "globals.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class EmLowEPPhysics : public G4VPhysicsConstructor
{
public:
  EmLowEPPhysics(const G4String& name = "low");

  virtual ~EmLowEPPhysics();

  virtual void ConstructParticle();
  virtual void ConstructProcess();

};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif






