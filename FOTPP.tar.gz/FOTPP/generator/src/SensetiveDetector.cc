#include "SensitiveDetector.hh"

#include "G4Step.hh"
#include "G4SystemOfUnits.hh"
#include <iomanip>
#include <fstream>

SensitiveDetector::SensitiveDetector(G4String name):
G4VSensitiveDetector(name){}

G4bool SensitiveDetector::ProcessHits(G4Step *step, G4TouchableHistory*)
{
    nameOfParticle = step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName();
    energy = step->GetTrack()->GetDynamicParticle()->GetKineticEnergy();
    std::ofstream file("MYlot.dat", std::ios::app);
    X = step->GetPreStepPoint()->GetPosition().x();
    Y = step->GetPreStepPoint()->GetPosition().y();
    file << std::setw(20) << i << std::setw(20) << X/angstrom << std::setw(20) << Y/angstrom << std::setw(20)
         << 0 << std::setw(20) << energy / GeV << std::setw(20) << 0 << std::setw(20) << 0 << std::setw(20) << 0 << std::endl;
    
    i++;
    step->GetTrack()->SetTrackStatus(fStopAndKill);
    return true;
}

SensitiveDetector::~SensitiveDetector(){}
