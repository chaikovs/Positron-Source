#include "DetectorConstruction.hh"
#include "SensitiveDetector.hh"

#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4VSensitiveDetector.hh"
#include "G4SystemOfUnits.hh"
#include "G4RunManager.hh"
#include "G4SDManager.hh"
#include "G4MultiFunctionalDetector.hh"
#include "G4VPrimitiveScorer.hh"
#include "G4PSEnergyDeposit.hh"
#include "G4SDParticleFilter.hh"
#include "G4VSDFilter.hh"

DetectorConstruction::DetectorConstruction():
G4VUserDetectorConstruction()
{
    DefineMaterials();
}

DetectorConstruction::~DetectorConstruction(){}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    return ConstructCalorimeter();
}

void DetectorConstruction::DefineMaterials()
{ 
    G4NistManager* nistManager = G4NistManager::Instance();
    Galactic = nistManager->FindOrBuildMaterial("G4_Galactic");
}

G4VPhysicalVolume* DetectorConstruction::ConstructCalorimeter()
{
    G4GeometryManager::GetInstance()->OpenGeometry();
    G4PhysicalVolumeStore::GetInstance()->Clean();
    G4LogicalVolumeStore::GetInstance()->Clean();
    G4SolidStore::GetInstance()->Clean();

    fSolidWorld = new G4Box("World", 1.*m, 1.*m, 1.*m);
                         
    fLogicWorld = new G4LogicalVolume(fSolidWorld, Galactic, "LWorld");

    fPhysiWorld = new G4PVPlacement(0, G4ThreeVector(), fLogicWorld, "PWorld", 0, false, 0);

    G4Box* fSolid = new G4Box("W", 1.*cm, 1.*cm, 1.*cm);
    
    G4LogicalVolume* fLogic = new G4LogicalVolume(fSolid, Galactic, "LW");
    
    new G4PVPlacement(0, G4ThreeVector(), fLogic, "PW", fLogicWorld, false, 0);
    
    SensitiveDetector *detector = new SensitiveDetector("SD");
    (G4SDManager::GetSDMpointer())->AddNewDetector(detector);
    fLogic->SetSensitiveDetector(detector);
    
    return fPhysiWorld;
}
