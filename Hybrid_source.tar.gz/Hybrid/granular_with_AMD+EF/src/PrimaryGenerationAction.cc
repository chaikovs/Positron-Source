#include "PrimaryGeneratorAction.hh"

#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "globals.hh"
#include <iomanip>
#include <fstream>
#include <assert.h>

PrimaryGeneratorAction::PrimaryGeneratorAction():
G4VUserPrimaryGeneratorAction()
{
    std::ifstream in;
    
    in.open("input.dat");
    
    assert(in.is_open());
    G4int i = 0;
    while(1)
    {
        in>>p[0][i]>>p[1][i]>>p[2][i]>>p[3][i]>>p[4][i];
        i++;
        if(!in.good()) break;
    }

    G4int numberOfTheParticles = 1;
    
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* particle = particleTable->FindParticle("gamma");
    
    fParticleGun = new G4ParticleGun(particle, numberOfTheParticles);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    G4double z0 = -2000*mm;
    
    fParticleGun->SetParticlePosition(G4ThreeVector(p[0][number]*10,p[1][number]*10,z0));
    fParticleGun->SetParticleMomentum(G4ParticleMomentum(p[2][number],p[3][number],p[4][number]));
    number++;
    fParticleGun->GeneratePrimaryVertex(anEvent);
}
