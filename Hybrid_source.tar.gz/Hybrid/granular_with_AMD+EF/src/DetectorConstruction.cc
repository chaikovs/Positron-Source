#include "DetectorConstruction.hh"
#include "DetectorMessenger.hh"
#include "SensitiveDetector.hh"
#include "SensitiveDetectorBefore.hh"
#include "SensitiveDetectorAfter.hh"
#include "SensitiveDetectorEM.hh"
//----------- MAGNETIC FIELD -----------
#include "MagneticField.hh"

#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Orb.hh"
#include "G4Tubs.hh"
#include "G4Cons.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4VSensitiveDetector.hh"
#include "G4SystemOfUnits.hh"
#include "G4RunManager.hh"
#include "G4SDManager.hh"
#include "G4MultiFunctionalDetector.hh"
#include "G4VPrimitiveScorer.hh"
#include "G4PSEnergyDeposit.hh"
#include "G4SDParticleFilter.hh"
#include "G4VSDFilter.hh"

DetectorConstruction::DetectorConstruction():
G4VUserDetectorConstruction(),
fDetectorMessenger(0)
{
    orbsInString = 10;
    numberOfLayers = 1;
    rOrb = 1.1*mm;
    DefineMaterials();
    G4NistManager* nistManager = G4NistManager::Instance();
    nistManager->SetVerbose(1);
    fDetectorMessenger = new DetectorMessenger(this);
}

DetectorConstruction::~DetectorConstruction()
{
    delete fDetectorMessenger;
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    return ConstructCalorimeter();
}

void DetectorConstruction::DefineMaterials()
{
    G4NistManager* nistManager = G4NistManager::Instance();
    Galactic = nistManager->FindOrBuildMaterial("G4_Galactic");
    W = nistManager->FindOrBuildMaterial("G4_W");
    Cu = nistManager->FindOrBuildMaterial("G4_Cu");
}

G4VPhysicalVolume* DetectorConstruction::ConstructCalorimeter()
{
    G4GeometryManager::GetInstance()->OpenGeometry();
    G4PhysicalVolumeStore::GetInstance()->Clean();
    G4LogicalVolumeStore::GetInstance()->Clean();
    G4SolidStore::GetInstance()->Clean();
    
    //------------------------------------- World ------------------------------------
    fSolidWorld=0; fLogicWorld=0; fPhysiWorld=0;
    
    fSolidWorld = new G4Box("World", 5.*m, 5.*m, 5.*m);
    
    fLogicWorld = new G4LogicalVolume(fSolidWorld, Galactic, "LWorld");
    
    fPhysiWorld = new G4PVPlacement(0, G4ThreeVector(), fLogicWorld, "PWorld", 0, false, 0);
    
    //----------------------- Sensitive Detector Before Target -----------------------
    fSolidSDB = new G4Box("SDB", 11*mm, 11*mm, 1.*nm);
    
    fLogicSDB = new G4LogicalVolume(fSolidSDB, Galactic, "LSDB");
    
    fPhysiSDB = new G4PVPlacement(0, G4ThreeVector(0., 0., -rOrb-1.*nm), fLogicSDB, "PSDB", fLogicWorld, false, 0);
    
    //------------------------------------ Target ------------------------------------
    fSolidTarget = new G4Orb("Target", rOrb);
    
    fLogicTarget = new G4LogicalVolume(fSolidTarget, W, "LTarget");
    
    G4VPhysicalVolume* fPhysiTarget[numberOfLayers*numberOfOrbs];
    for(G4int k = 0; k < numberOfLayers; ++k)
    {
        for(G4int i = 0; i < orbsInString; ++i)
        {
            for(G4int j = 0; j < orbsInString; ++j)
            {
                G4double z = k*2*rOrb*std::sqrt(3);
                G4ThreeVector orbPos((2*i-orbsInString+1)*rOrb,(2*j-orbsInString+1)*rOrb,z);
                fPhysiTarget[i*orbsInString+j+numberOfOrbs*k] = new G4PVPlacement(0, orbPos, fLogicTarget, "PTarget", fLogicWorld, false, i*orbsInString+j+numberOfOrbs*k);
            }
        }
        
        for(G4int i = 0; i < orbsInString-1; ++i)
        {
            for(G4int j = 0; j < orbsInString-1; ++j)
            {
                G4double z = rOrb*std::sqrt(3) + k*2*rOrb*std::sqrt(3);
                G4ThreeVector orbPos(2*rOrb*(i-orbsInString/2+1),2*rOrb*(j-orbsInString/2+1),z);
                fPhysiTarget[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k] = new G4PVPlacement(0, orbPos, fLogicTarget, "PTarget", fLogicWorld, false, (orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k);
            }
        }
    }
    //--------------------------------------------------------------------------------
    targetThickness = (2*numberOfLayers-1)*rOrb*std::sqrt(3) + rOrb;
    
    //------------------------ Sensitive Detector After Target -----------------------
    fSolidSDA = new G4Box("SDA", 22*mm, 22*mm, 1.*nm);
    
    fLogicSDA = new G4LogicalVolume(fSolidSDA, Galactic, "LSDA");
    
    fPhysiSDA = new G4PVPlacement(0, G4ThreeVector(0., 0., targetThickness + 1.*nm), fLogicSDA, "PSDA", fLogicWorld, false, 0);
    
    //------------------------------------ Magnet ------------------------------------
    fSolidM = new G4Cons("Magnet", 0., 17.*mm, 0., 22.*mm, 250.*mm, 0., 360.*deg);
    
    fLogicM = new G4LogicalVolume(fSolidM, Cu, "LMagnet");
    
    fPhysiM = new G4PVPlacement(0, G4ThreeVector(0., 0., 250.*mm + targetThickness + 2.*nm), fLogicM, "PMagnet", fLogicWorld, false, 0);
    
    //-------------------------- Volume With Magnetic Field --------------------------
    fSolidMF = new G4Cons("MF", 0., 15.*mm, 0., 20.*mm, 250.*mm, 0., 360.*deg);
    
    fLogicMF = new G4LogicalVolume(fSolidMF, Galactic, "LMF");
    
    fPhysiMF = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.), fLogicMF, "PMF", fLogicM, false, 0);
    
    //------------------------ Sensitive Detector After Magnet ------------------------
    fSolidSD = new G4Tubs("SD", 0., 20.*mm, 1.*nm, 0., 360.*deg);
    
    fLogicSD = new G4LogicalVolume(fSolidSD, Galactic, "LSD");
    
    fPhysiSD = new G4PVPlacement(0, G4ThreeVector(0., 0., 500.*mm + targetThickness + 3.*nm), fLogicSD, "PSD", fLogicWorld, false, 0);

    //------------------------------------ Accelerator ------------------------------------
    fSolidEM = new G4Tubs("ElMagnet", 0., 22.*mm, 500.*mm, 0., 360.*deg);

    fLogicEM = new G4LogicalVolume(fSolidEM, Cu, "LElMagnet");

    fPhysiEM = new G4PVPlacement(0, G4ThreeVector(0., 0., 1000.*mm + targetThickness + 4.*nm), fLogicEM, "PElMagnet", fLogicWorld, false, 0);

    //-------------------------- Volume With ElectroMagnetic Field --------------------------
    fSolidEMF = new G4Tubs("EMF", 0., 20.*mm, 500.*mm, 0., 360.*deg);

    fLogicEMF = new G4LogicalVolume(fSolidEMF, Galactic, "LEMF");

    fPhysiEMF = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.), fLogicEMF, "PMF", fLogicEM, false, 0);

    //------------------------ Sensitive Detector After Accelerator ------------------------
    fSolidEMSD = new G4Tubs("EMSD", 0., 20.*mm, 1.*nm, 0., 360.*deg);

    fLogicEMSD = new G4LogicalVolume(fSolidEMSD, Galactic, "LEMSD");

    fPhysiEMSD = new G4PVPlacement(0, G4ThreeVector(0., 0., 1500.*mm + targetThickness + 5.*nm), fLogicEMSD, "PEMSD", fLogicWorld, false, 0);

    return fPhysiWorld;
}

void DetectorConstruction::SetNumberOfLayers(const G4int val)
{
    numberOfLayers = val;
    G4RunManager::GetRunManager()->ReinitializeGeometry();
}

double DetectorConstruction::GetTargetThickness() const
{
    return targetThickness;
}

G4ThreadLocal MagneticField* DetectorConstruction::magField = 0;
void DetectorConstruction::ConstructSDandField()
{
    static G4ThreadLocal G4bool initialized = false;
    if(!initialized)
    {
        SensitiveDetector *detector = new SensitiveDetector("Sensitive Detector After Magnet");
        (G4SDManager::GetSDMpointer())->AddNewDetector(detector);
        fLogicSD->SetSensitiveDetector(detector);
        SensitiveDetectorBefore *detectorBefore = new SensitiveDetectorBefore("Sensitive Detector Before Target");
        (G4SDManager::GetSDMpointer())->AddNewDetector(detectorBefore);
        fLogicSDB->SetSensitiveDetector(detectorBefore);
        SensitiveDetectorAfter *detectorAfter = new SensitiveDetectorAfter("Sensitive Detector After Target");
        (G4SDManager::GetSDMpointer())->AddNewDetector(detectorAfter);
        fLogicSDA->SetSensitiveDetector(detectorAfter);
        SensitiveDetectorEM *detectorEM = new SensitiveDetectorEM("Sensitive Detector After Accelerator");
        (G4SDManager::GetSDMpointer())->AddNewDetector(detectorEM);
        fLogicEMSD->SetSensitiveDetector(detectorEM);
        initialized = false;
    }
    
    if(!magField)
    {
        magField = new MagneticField();
    }
}
