void AFTER_E() {
    
    ifstream in[3];
    Double_t p[3];
    TPaveStats *ps[3];
    TH1F *h[3];

    TCanvas *c1 = new TCanvas("Canvas1", "Canvas", 1280, 720);
    c1->SetLogy(1);

    in[0].open("../AFTER_TARGET/E_E.dat");
    in[1].open("../AFTER_MAGNET/E_E.dat");
    in[2].open("../AFTER_EM/E_E.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target E","Energy spectrum of the electrons",100,0,10000);
    h[0]->GetXaxis()->SetTitle("Energy, MeV");
    h[0]->GetYaxis()->SetTitle("dN/dE [1/(100*MeV)]");
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD E"," ",100,0,10000);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator E"," ",100,0,10000);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    int i = 0;
    int j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_E_E.png");
            break;
        }
        h[2]->Fill(p[2]);
    }

    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();


    in[0].open("../AFTER_TARGET/E_P.dat");
    in[1].open("../AFTER_MAGNET/E_P.dat");
    in[2].open("../AFTER_EM/E_P.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target Phi","Angular distribution of the electrons (Phi)",180,-180,180);
    h[0]->GetXaxis()->SetTitle("Phi, deg");
    h[0]->GetYaxis()->SetTitle("dN/dPhi [1/(2*deg)]");
    h[0]->GetYaxis()->SetRangeUser(40, 2000);
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD Phi"," ",180,-180,180);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator Phi"," ",180,-180,180);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_E_P.png");
            break;
        }
        h[2]->Fill(p[2]);
    }

    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();


    in[0].open("../AFTER_TARGET/E_T.dat");
    in[1].open("../AFTER_MAGNET/E_T.dat");
    in[2].open("../AFTER_EM/E_T.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target Theta","Angular distribution of the electrons (Theta)",180,0,180);
    h[0]->GetXaxis()->SetTitle("Theta, deg");
    h[0]->GetYaxis()->SetTitle("dN/dTheta [1/deg]");
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD Theta"," ",180,0,180);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator Theta"," ",180,0,180);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_E_T.png");
            break;
        }
        h[2]->Fill(p[2]);
    }


    c1->Close();
}



