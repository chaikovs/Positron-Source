int color(double par)
{
    int q = 0;
    if(par <= 0.2)
    {
        q = -10;
    }
    else
    {
        if(par <= 0.3 && par > 0.2)
        {
            q = -9;
        }
        else
        {
            if(par <= 0.4 && par > 0.3)
            {
                q = -7;
            }
            else
            {
                if(par <= 0.5 && par > 0.4)
                {
                    q = -4;
                }
                else
                {
                    if(par <= 0.6 && par > 0.5)
                    {
                        q = 0;
                    }
                    else
                    {
                        if(par <= 0.7 && par > 0.6)
                        {
                            q = 1;
                        }
                        else
                        {
                            if(par <= 0.8 && par > 0.7)
                            {
                                q = 2;
                            }
                            else
                            {
                                if(par <= 0.9 && par > 0.8)
                                {
                                    q = 3;
                                }
                                else
                                {
                                    if(par <= 1 && par > 0.9)
                                    {
                                        q = 4;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return q;
}
void TARGET_P_x_y_z_e_COL()
{
    ifstream in;
    in.open("../TARGET/B_DE.dat");
    assert(in.is_open());
    double max = 0;
    
    double par[905];
    
    TCanvas *c1 = new TCanvas("Canvas1", "Canvas", 720, 720);
    

    int i = 0;
    while(1)
    {
        in>>par[i];
        if(!in.good()) break;
        if(max < par[i]) max = par[i];
        i++;
    }
    
    double x[5] = {-13, -13, 13, 13, -13};
    double y[5] = {-13, 13, 13, -13, -13};
    TGraph *g = new TGraph(5, x, y);
    g->SetLineColor(kWhite);
    g->Draw();
    
    for(int i = 0; i < 905; ++i)
    {
        par[i] = par[i]/max;
    }
    /*----------------*/
    std::ofstream file("MAX.dat", std::ios::app);
    file << std::setw(10) << max << " " << std::endl;
    /*----------------*/
    int orbsInString = 10;
    int numberOfOrbs = 181;
    double rOrb = 1.1;

    for(int k = 0; k < 3; ++k)
    {
        for(int i = 0; i < orbsInString-1; ++i)
        {
            for(int j = 0; j < orbsInString-1; ++j)
            {
                TMarker *m = new TMarker(2*rOrb*(i-orbsInString/2+1)-5, 2*rOrb*(j-orbsInString/2+1), 20);
                m->SetMarkerSize(4.5);
                int w = numberOfOrbs*k+(orbsInString*orbsInString)+i*(orbsInString-1)+j;
                m->SetMarkerColor(kCyan + color(par[w]));
                m->Draw();
            }
            for(int i = 0; i < orbsInString; ++i)
            {
                for(int j = 0; j < orbsInString; ++j)
                {
                    TMarker *m = new TMarker((2*i-orbsInString + 1)*rOrb-5, (2*j-orbsInString + 1)*rOrb, 20);
                    m->SetMarkerSize(4.5);
                    int w = numberOfOrbs*k+i*orbsInString+j;
                    m->SetMarkerColor(kMagenta + color(par[w]));
                    m->Draw();
                }
            }
        }

        int col[9] = {-10, -9, -7, -4, 0, 1, 2, 3, 4};
        for(int i = 0; i < 9; ++i)
        {
            TMarker *pal = new TMarker(8, (2*i-orbsInString + 1)*rOrb + 0.6, 20);
            pal->SetMarkerSize(4.5);
            pal->SetMarkerColor(kMagenta + col[i]);
            pal->Draw();

        }
        TText *name = new TText(7, 11, "Edep in sphere");
        name->Draw();
        TText *t[9];
        t[0] = new TText(12,(-orbsInString + 1)*rOrb,"(0; 0.2]");
        t[1] = new TText(12,(2-orbsInString + 1)*rOrb,"(0.2; 0.3]");
        t[2] = new TText(12,(4-orbsInString + 1)*rOrb,"(0.3; 0.4]");
        t[3] = new TText(12,(6-orbsInString + 1)*rOrb,"(0.4; 0.5]");
        t[4] = new TText(12,(8-orbsInString + 1)*rOrb,"(0.5; 0.6]");
        t[5] = new TText(12,(10-orbsInString + 1)*rOrb,"(0.6; 0.7]");
        t[6] = new TText(12,(12-orbsInString + 1)*rOrb,"(0.7; 0.8]");
        t[7] = new TText(12,(14-orbsInString + 1)*rOrb,"(0.8; 0.9]");
        t[8] = new TText(12,(16-orbsInString + 1)*rOrb,"(0.9; 1]");

        for(int i = 0; i < 9; ++i)
        {
            t[i]->Draw();
            TMarker *pal = new TMarker(10, (2*i-orbsInString + 1)*rOrb + 0.6, 20);
            pal->SetMarkerSize(4.5);
            pal->SetMarkerColor(kCyan + col[i]);
            pal->Draw();
        }

        if(k==0){ c1->SaveAs("../PNG/TARGET_LAY_1.png"); c1->Clear();}
        if(k==1){ c1->SaveAs("../PNG/TARGET_LAY_2.png"); c1->Clear();}
        if(k==2){ c1->SaveAs("../PNG/TARGET_LAY_3.png"); c1->Clear();}
        //if(k==3){ c1->SaveAs("../PNG/TARGET_LAY_4.png"); c1->Clear();}
        //if(k==4){ c1->SaveAs("../PNG/TARGET_LAY_5.png"); c1->Clear();}
    }
    for(int i = 0; i < orbsInString-1; ++i)
    {
        for(int j = 0; j < orbsInString-1; ++j)
        {
            TMarker *m = new TMarker(2*rOrb*(i-orbsInString/2+1)-5, 2*rOrb*(j-orbsInString/2+1), 20);
            m->SetMarkerSize(4.5);
            int w = (orbsInString*orbsInString)+i*(orbsInString-1)+j;
            m->SetMarkerColor(kCyan + color(par[w]));
            m->Draw();
        }
    }
    for(int i = 0; i < orbsInString; ++i)
    {
        for(int j = 0; j < orbsInString; ++j)
        {
            TMarker *m = new TMarker((2*i-orbsInString + 1)*rOrb-5, (2*j-orbsInString + 1)*rOrb, 20);
            m->SetMarkerSize(4.5);
            int w = i*orbsInString+j;
            m->SetMarkerColor(kMagenta + color(par[w]));
            m->Draw();
        }
    }
    int col[9] = {-10, -9, -7, -4, 0, 1, 2, 3, 4};
    for(int i = 0; i < 9; ++i)
    {
        TMarker *pal = new TMarker(8, (2*i-orbsInString + 1)*rOrb + 0.6, 20);
        pal->SetMarkerSize(4.5);
        pal->SetMarkerColor(kMagenta + col[i]);
        pal->Draw();

    }
    TText *name = new TText(7, 11, "Edep in sphere");
    name->Draw();
    TText *t[9];
    t[0] = new TText(12,(-orbsInString + 1)*rOrb,"(0; 0.2]");
    t[1] = new TText(12,(2-orbsInString + 1)*rOrb,"(0.2; 0.3]");
    t[2] = new TText(12,(4-orbsInString + 1)*rOrb,"(0.3; 0.4]");
    t[3] = new TText(12,(6-orbsInString + 1)*rOrb,"(0.4; 0.5]");
    t[4] = new TText(12,(8-orbsInString + 1)*rOrb,"(0.5; 0.6]");
    t[5] = new TText(12,(10-orbsInString + 1)*rOrb,"(0.6; 0.7]");
    t[6] = new TText(12,(12-orbsInString + 1)*rOrb,"(0.7; 0.8]");
    t[7] = new TText(12,(14-orbsInString + 1)*rOrb,"(0.8; 0.9]");
    t[8] = new TText(12,(16-orbsInString + 1)*rOrb,"(0.9; 1]");

    for(int i = 0; i < 9; ++i)
    {
        t[i]->Draw();
        TMarker *pal = new TMarker(10, (2*i-orbsInString + 1)*rOrb + 0.6, 20);
        pal->SetMarkerSize(4.5);
        pal->SetMarkerColor(kCyan + col[i]);
        pal->Draw();
    }

    c1->SaveAs("../PNG/TARGET_LAY_1.png");
    c1->Close();
}


