void AFTER_P() {

    ifstream in[3];
    Double_t p[3];
    TPaveStats *ps[3];
    TH1F *h[3];

    TCanvas *c1 = new TCanvas("Canvas1", "Canvas", 1280, 720);
    c1->SetLogy(1);

    in[0].open("../AFTER_TARGET/P_E.dat");
    in[1].open("../AFTER_MAGNET/P_E.dat");
    in[2].open("../AFTER_EM/P_E.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target E","Energy spectrum of the positrons",100,0,10000);
    h[0]->GetXaxis()->SetTitle("Energy, MeV");
    h[0]->GetYaxis()->SetTitle("dN/dE [1/(100*MeV)]");
    //h[0]->GetYaxis()->SetRangeUser(1, 10000);
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD E"," ",100,0,10000);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator E"," ",100,0,10000);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    int i = 0;
    int j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            //if(p[0]<=100)
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            //if(p[1]<=100)
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_P_E.png");
            break;
        }
        //if(p[2]<=100)
        h[2]->Fill(p[2]);
    }

    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();


    in[0].open("../AFTER_TARGET/P_P.dat");
    in[1].open("../AFTER_MAGNET/P_P.dat");
    in[2].open("../AFTER_EM/P_P.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target Phi","Angular distribution of the positrons (Phi)",180,-180,180);
    h[0]->GetXaxis()->SetTitle("Phi, deg");
    h[0]->GetYaxis()->SetTitle("dN/dPhi [1/(2*deg)]");
    h[0]->GetYaxis()->SetRangeUser(100, 1000);
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD Phi"," ",180,-180,180);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator Phi"," ",180,-180,180);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_P_P.png");
            break;
        }
        h[2]->Fill(p[2]);
    }

    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();


    in[0].open("../AFTER_TARGET/P_T.dat");
    in[1].open("../AFTER_MAGNET/P_T.dat");
    in[2].open("../AFTER_EM/P_T.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target Theta","Angular distribution of the positrons (Theta)",180,0,180);
    h[0]->GetXaxis()->SetTitle("Theta, deg");
    h[0]->GetYaxis()->SetTitle("dN/dTheta [1/deg]");
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD Theta"," ",180,0,180);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator Theta"," ",180,0,180);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_P_T.png");
            break;
        }
        h[2]->Fill(p[2]);
    }


    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();


    c1->SetLogy(0);
    in[0].open("../AFTER_TARGET/P_X.dat");
    in[1].open("../AFTER_MAGNET/P_X.dat");
    in[2].open("../AFTER_EM/P_X.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target X","Positron beam (X)",100,-20,20);
    h[0]->GetXaxis()->SetTitle("X, mm");
    h[0]->GetYaxis()->SetTitle("dN/dX [1/(0.4*mm)]");
    h[0]->GetYaxis()->SetRangeUser(0, 7500);
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD X"," ",100,-20,20);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator X"," ",100,-20,20);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_P_X.png");
            break;
        }
        h[2]->Fill(p[2]);
    }

    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();


    in[0].open("../AFTER_TARGET/P_Y.dat");
    in[1].open("../AFTER_MAGNET/P_Y.dat");
    in[2].open("../AFTER_EM/P_Y.dat");
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());

    h[0] = new TH1F("After Target Y","Positron beam (Y)",100,-20,20);
    h[0]->GetXaxis()->SetTitle("Y, mm");
    h[0]->GetYaxis()->SetTitle("dN/dY [1/(0.4*mm)]");
    h[0]->GetYaxis()->SetRangeUser(0, 7500);
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD Y"," ",100,-20,20);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator Y"," ",100,-20,20);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    while (1)
    {
        while(i == 0)
        {
            in[0]>>p[0];
            if(!in[0].good())
            {
                i = 1;
                in[0].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            h[0]->Fill(p[0]);
        }
        while(j == 0)
        {
            in[1]>>p[1];
            if(!in[1].good())
            {
                j = 1;
                in[1].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            h[1]->Fill(p[1]);
        }

        in[2]>>p[2];
        if(!in[2].good())
        {
            in[2].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_P_Y.png");
            break;
        }
        h[2]->Fill(p[2]);
    }



    ifstream inm[9];
    Double_t pm[3];

    c1->Clear();
    ps[0]->Clear();
    ps[1]->Clear();
    ps[2]->Clear();
    h[0]->Delete();
    h[1]->Delete();
    h[2]->Delete();

    
    c1->SetLogy(1);
    inm[0].open("../AFTER_TARGET/P_MX.dat");
    inm[1].open("../AFTER_MAGNET/P_MX.dat");
    inm[2].open("../AFTER_EM/P_MX.dat");
    inm[3].open("../AFTER_TARGET/P_MY.dat");
    inm[4].open("../AFTER_MAGNET/P_MY.dat");
    inm[5].open("../AFTER_EM/P_MY.dat");
    inm[6].open("../AFTER_TARGET/P_MZ.dat");
    inm[7].open("../AFTER_MAGNET/P_MZ.dat");
    inm[8].open("../AFTER_EM/P_MZ.dat");
    assert(inm[0].is_open());
    assert(inm[1].is_open());
    assert(inm[2].is_open());
    assert(inm[3].is_open());
    assert(inm[4].is_open());
    assert(inm[5].is_open());
    assert(inm[6].is_open());
    assert(inm[7].is_open());
    assert(inm[8].is_open());

    h[0] = new TH1F("After Target Mt","Transverse momentum of the positrons",100,0,1);
    h[0]->GetXaxis()->SetTitle("Mt/M");
    h[0]->GetYaxis()->SetTitle("dN/(Mt/M) [1/(0.01*Mt/M)]");
    h[0]->GetYaxis()->SetRangeUser(1, 40000);
    h[0]->SetLineColor(kBlue);
    h[0]->SetFillColorAlpha(kBlue, 0.4);
    h[0]->SetFillStyle(3001);
    h[1] = new TH1F("After AMD Mt"," ",100,0,1);
    h[1]->SetLineColor(kRed);
    h[1]->SetFillColorAlpha(kRed, 0.4);
    h[1]->SetFillStyle(3001);
    h[2] = new TH1F("After Accelerator Mt"," ",100,0,1);
    h[2]->SetLineColor(kGreen);
    h[2]->SetFillColorAlpha(kGreen, 0.4);
    h[2]->SetFillStyle(3001);

    i = 0;
    j = 0;
    Double_t pa;
    while (1)
    {
        while(i == 0)
        {
            inm[0]>>pm[0];
            inm[3]>>pm[1];
            inm[6]>>pm[2];
            if(!inm[0].good())
            {
                i = 1;
                inm[0].close();
                inm[3].close();
                inm[6].close();
                h[0]->Draw();
                c1->Update();
                ps[0] = (TPaveStats*)h[0]->GetListOfFunctions()->FindObject("stats");
                ps[0]->SetX1NDC(0.15);
                ps[0]->SetX2NDC(0.35);
                ps[0]->SetTextColor(kBlue);
                c1->cd();
                break;
            }
            pa = sqrt(pm[0]*pm[0]+pm[1]*pm[1])/sqrt(pm[0]*pm[0]+pm[1]*pm[1]+pm[2]*pm[2]);
            //if(pa <= 0.2)
                h[0]->Fill(pa);
        }
        while(j == 0)
        {
            inm[1]>>pm[0];
            inm[4]>>pm[1];
            inm[7]>>pm[2];
            if(!inm[1].good())
            {
                j = 1;
                inm[1].close();
                inm[4].close();
                inm[7].close();
                h[1]->Draw("][sames");
                c1->Update();
                ps[1] = (TPaveStats*)h[1]->GetListOfFunctions()->FindObject("stats");
                ps[1]->SetX1NDC(0.4);
                ps[1]->SetX2NDC(0.6);
                ps[1]->SetTextColor(kRed);
                c1->cd();
                break;
            }
            pa = sqrt(pm[0]*pm[0]+pm[1]*pm[1])/sqrt(pm[0]*pm[0]+pm[1]*pm[1]+pm[2]*pm[2]);
            //if(pa <= 0.2)
                h[1]->Fill(pa);
        }

        inm[2]>>pm[0];
        inm[5]>>pm[1];
        inm[8]>>pm[2];
        if(!inm[2].good())
        {
            inm[2].close();
            inm[5].close();
            inm[8].close();
            h[2]->Draw("][sames");
            c1->Update();
            ps[2] = (TPaveStats*)h[2]->GetListOfFunctions()->FindObject("stats");
            ps[2]->SetX1NDC(0.65);
            ps[2]->SetX2NDC(0.85);
            ps[2]->SetTextColor(kGreen);
            c1->cd();
            c1->Update();
            c1->Print("../PNG/AFTER_P_MT.png");
            break;
        }
        pa = sqrt(pm[0]*pm[0]+pm[1]*pm[1])/sqrt(pm[0]*pm[0]+pm[1]*pm[1]+pm[2]*pm[2]);
        //if(pa <= 0.2)
            h[2]->Fill(pa);
    }


    c1->Close();
}







