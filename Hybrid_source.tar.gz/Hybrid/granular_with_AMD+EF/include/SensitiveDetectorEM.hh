#ifndef SENSITIVEDETECTOREM
#define SENSITIVEDETECTOREM_H

#include <G4VSensitiveDetector.hh>

class G4Step;
class G4TouchableHistory;

class SensitiveDetectorEM: public G4VSensitiveDetector
{
private:
    G4String nameOfParticle;
    G4double energy;
    G4double momentumX;
    G4double momentumY;
    G4double momentumZ;
    G4double momentumDirectionPhi;
    G4double momentumDirectionTheta;
    G4double X;
    G4double Y;
public:
    SensitiveDetectorEM(G4String name);
    ~SensitiveDetectorEM();
    G4bool ProcessHits(G4Step *step, G4TouchableHistory*);
};

#endif
