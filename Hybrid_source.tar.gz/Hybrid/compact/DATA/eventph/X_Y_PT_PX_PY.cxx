void X_Y_PT_PX_PY() {
    
    ifstream in1[5];
    Double_t par1[5];

    TCanvas *c1 = new TCanvas("Canvas1", "Canvas", 1280, 720);
    in1[0].open("px.dat");
    in1[1].open("py.dat");
    in1[2].open("pz.dat");
    in1[3].open("x.dat");
    in1[4].open("y.dat");
    assert(in1[0].is_open());
    assert(in1[1].is_open());
    assert(in1[2].is_open());
    assert(in1[3].is_open());
    assert(in1[4].is_open());

    TH2F *h1 = new TH2F("PX(X)","Momentum projection (X)",200,-1.5,1.5,200,-1,1);
    h1->GetXaxis()->SetTitle("X, mm");
    h1->GetXaxis()->SetTitleOffset(1.5);
    h1->GetYaxis()->SetTitle("Px/P");
    h1->GetYaxis()->SetTitleOffset(1.5);
    h1->GetZaxis()->SetTitle("Number of the particles");
    h1->GetZaxis()->SetTitleOffset(1.5);
    h1->SetMarkerColor(kAzure+10);

    TH2F *h2 = new TH2F("PY(Y)","Momentum projection (Y)",200,-1.5,1.5,200,-1,1);
    h2->GetXaxis()->SetTitle("Y, mm");
    h2->GetXaxis()->SetTitleOffset(1.5);
    h2->GetYaxis()->SetTitle("Py/P");
    h2->GetYaxis()->SetTitleOffset(1.5);
    h2->GetZaxis()->SetTitle("Number of the particles");
    h2->GetZaxis()->SetTitleOffset(1.5);
    h2->SetMarkerColor(kAzure+10);
    
    TH1F *h3 = new TH1F("X","Beam (X)",200,-1.5,1.5);
    h3->GetXaxis()->SetTitle("X, mm");
    h3->GetXaxis()->SetTitleOffset(1.5);
    h3->GetYaxis()->SetTitle("Number of the particles");
    h3->GetYaxis()->SetTitleOffset(1.5);
    h3->SetLineColor(kAzure+10);
    h3->SetFillColorAlpha(kAzure+10, 0.1);
    h3->SetFillStyle(3001);

    TH1F *h4 = new TH1F("Y","Beam (Y)",200,-1.5,1.5);
    h4->GetXaxis()->SetTitle("Y, mm");
    h4->GetXaxis()->SetTitleOffset(1.5);
    h4->GetYaxis()->SetTitle("Number of the particles");
    h4->GetYaxis()->SetTitleOffset(1.5);
    h4->SetLineColor(kAzure+10);
    h4->SetFillColorAlpha(kAzure+10, 0.1);
    h4->SetFillStyle(3001);
    
    TH1F *h5 = new TH1F("PT","Transverse momentum",200,0,1);
    h5->GetXaxis()->SetTitle("PT/P");
    h5->GetXaxis()->SetTitleOffset(1.5);
    h5->GetYaxis()->SetTitle("Number of the particles");
    h5->GetYaxis()->SetTitleOffset(1.5);
    h5->SetLineColor(kAzure+10);
    h5->SetFillColorAlpha(kAzure+10, 0.1);
    h5->SetFillStyle(3001);
    
    while (1)
    {
        in1[0]>>par1[0];
        in1[1]>>par1[1];
        in1[2]>>par1[2];
        in1[3]>>par1[3];
        in1[4]>>par1[4];
        if(!in1[0].good())
        {
            in1[0].close();
            in1[1].close();
            in1[2].close();
            in1[3].close();
            in1[4].close();
            h1->Draw();
            c1->Update();
            c1->cd();
            c1->SaveAs("x_px.png");
            h2->Draw();
            c1->Update();
            c1->cd();
            c1->SaveAs("y_py.png");
            c1->SetLogy(1);
            h3->Draw();
            c1->Update();
            c1->cd();
            c1->SaveAs("x.png");
            h4->Draw();
            c1->Update();
            c1->cd();
            c1->SaveAs("y.png");
            h5->Draw();
            c1->Update();
            c1->cd();
            c1->SaveAs("pt.png");
            break;
        }
        h1->Fill(par1[3], par1[0]/sqrt(par1[0]*par1[0] + par1[1]*par1[1] + par1[2]*par1[2]));
        h2->Fill(par1[4], par1[1]/sqrt(par1[0]*par1[0] + par1[1]*par1[1] + par1[2]*par1[2]));
        h3->Fill(par1[3]);
        h4->Fill(par1[4]);
        h5->Fill(sqrt(par1[0]*par1[0] + par1[1]*par1[1])/sqrt(par1[0]*par1[0] + par1[1]*par1[1] + par1[2]*par1[2]));
    }
    c1->Close();
}



