#include "PrimaryGeneratorAction.hh"
#include "DetectorConstruction.hh"

#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "globals.hh"
#include <iomanip>
#include <fstream>
#include <assert.h>

PrimaryGeneratorAction::PrimaryGeneratorAction():
G4VUserPrimaryGeneratorAction()
{
    fDetector = new DetectorConstruction();
    
    std::ifstream in[5];
    
    in[0].open("eventph/px.dat");
    in[1].open("eventph/py.dat");
    in[2].open("eventph/pz.dat");
    in[3].open("eventph/x.dat");
    in[4].open("eventph/y.dat");
    
    assert(in[0].is_open());
    assert(in[1].is_open());
    assert(in[2].is_open());
    assert(in[3].is_open());
    assert(in[4].is_open());
    G4int i = 0;
    while(1)
    {
        in[0]>>p[0][i];
        in[1]>>p[1][i];
        in[2]>>p[2][i];
        in[3]>>p[3][i];
        in[4]>>p[4][i];
        i++;
        if(!in[0].good()) break;
    }

    
    G4int numberOfTheParticles = 1;
    
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* particle = particleTable->FindParticle("gamma");
    
    fParticleGun = new G4ParticleGun(particle, numberOfTheParticles);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    G4double z0 = /**/-fDetector->GetTargetThickness()-2.*nm;
    
    fParticleGun->SetParticlePosition(G4ThreeVector(p[3][number]*10,p[4][number]*10,z0));
    fParticleGun->SetParticleMomentum(G4ParticleMomentum(p[0][number],p[1][number],p[2][number]));
    number++;
    fParticleGun->GeneratePrimaryVertex(anEvent);
}
