#include "DetectorMessenger.hh"
#include "DetectorConstruction.hh"

#include "G4UIdirectory.hh"
#include "G4UIcmdWithAnInteger.hh"
DetectorMessenger::DetectorMessenger( DetectorConstruction* Det):
G4UImessenger(),
fDetector(Det)
{ 
    fDir = new G4UIdirectory("/layout/");
    fDir->SetGuidance("UI commands of positron production project");

    G4bool broadcast = false;
    fDetDir = new G4UIdirectory("/layout/number/",broadcast);
    fDetDir->SetGuidance("detector control");
    
    fNumberOfLayoutsCmd = new G4UIcmdWithAnInteger("/layout/number/SetNumberOfLayouts",this);
    fNumberOfLayoutsCmd->SetParameterName("Size",false);
    fNumberOfLayoutsCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
}

DetectorMessenger::~DetectorMessenger()
{
    delete fNumberOfLayoutsCmd;
    delete fDetDir;
    delete fDir;
}

void DetectorMessenger::SetNewValue(G4UIcommand* command, G4String newValue)
{
    if( command == fNumberOfLayoutsCmd )
    {
        fDetector->SetNumberOfLayers(fNumberOfLayoutsCmd->GetNewIntValue(newValue));
    }
}
