#include "SteppingAction.hh"
#include "DetectorConstruction.hh"
#include "EventAction.hh"

#include "G4Step.hh"
#include "G4SystemOfUnits.hh"
#include "G4Track.hh"
#include "G4VPhysicalVolume.hh"
#include "G4VProcess.hh"
#include "Randomize.hh"
#include <iomanip>
#include <fstream>

SteppingAction::SteppingAction(DetectorConstruction* det, EventAction* evt):
G4UserSteppingAction(),
fDetector(det), fEventAction(evt), trackID(0)
{
    rOrb = 1.1*mm;
    for(G4int k = 0; k < numberOfLayers; ++k)
    {
        for(G4int i = 0; i < orbsInString; ++i)/*(2*i-orbsInString + 1)*rOrb*/
        {
            for(G4int j = 0; j < orbsInString; ++j)/*(2*j-orbsInString + 1)*rOrb*/
            {
                depEn[i*orbsInString+j+numberOfOrbs*k] = 0;
                number[i*orbsInString+j+numberOfOrbs*k] = 0;
            }
        }
        for(G4int i = 0; i < orbsInString-1; ++i)/*2*rOrb*(i-orbsInString/2+1)*/
        {
            for(G4int j = 0; j < orbsInString-1; ++j)/*2*rOrb*(j-orbsInString/2+1)*/
            {
                depEn[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k] = 0;
                number[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k] = 0;
            }
        }
    }
}

SteppingAction::~SteppingAction()
{
    std::ofstream fileBijk("TARGET/B_ijk.dat", std::ios::app);
    std::ofstream fileBN("TARGET/B_N.dat", std::ios::app);
    std::ofstream fileBDE("TARGET/B_DE.dat", std::ios::app);
    for(G4int k = 0; k < numberOfLayers; ++k)
    {
        for(G4int i = 0; i < orbsInString; ++i)/*(2*i-orbsInString + 1)*rOrb*/
        {
            for(G4int j = 0; j < orbsInString; ++j)/*(2*j-orbsInString + 1)*rOrb*/
            {
                fileBijk << std::setw(20) << i*orbsInString+j+numberOfOrbs*k << std::endl;
                fileBN << std::setw(20) << number[i*orbsInString+j+numberOfOrbs*k] << std::endl;
                fileBDE << std::setw(20) << depEn[i*orbsInString+j+numberOfOrbs*k] << std::endl;
            }
        }
        for(G4int i = 0; i < orbsInString-1; ++i)/*2*rOrb*(i-orbsInString/2+1)*/
        {
            for(G4int j = 0; j < orbsInString-1; ++j)/*2*rOrb*(j-orbsInString/2+1)*/
            {
                fileBijk << std::setw(20) << (orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k << std::endl;
                fileBN << std::setw(20) << number[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k] << std::endl;
                fileBDE << std::setw(20) << depEn[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k] << std::endl;
            }
        }
    }
}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
    if(step->GetPreStepPoint()->GetPosition().z()>= -rOrb &&
       step->GetPreStepPoint()->GetPosition().z()<= fDetector->GetTargetThickness())
    {
        G4VPhysicalVolume* where = step->GetTrack()->GetNextVolume();
        G4double edep = step->GetTotalEnergyDeposit();
        fEventAction->AddAbs(edep);
        nameOfParticle = step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName();
        if(nameOfParticle == "e+")
        {
            Energy = step->GetTrack()->GetDynamicParticle()->GetKineticEnergy();
            MomentumX = step->GetTrack()->GetDynamicParticle()->GetMomentum().x();
            MomentumY = step->GetTrack()->GetDynamicParticle()->GetMomentum().y();
            MomentumZ = step->GetTrack()->GetDynamicParticle()->GetMomentum().z();
            MomentumDirectionPhi = step->GetTrack()->GetDynamicParticle()->GetMomentumDirection().phi()*180/M_PI;
            MomentumDirectionTheta = step->GetTrack()->GetDynamicParticle()->GetMomentumDirection().theta()*180/M_PI;
            X = step->GetPreStepPoint()->GetPosition().x();
            Y = step->GetPreStepPoint()->GetPosition().y();
            Z = step->GetPreStepPoint()->GetPosition().z() + rOrb;
            ID = step->GetTrack()->GetTrackID();
            firstStepInVolume = step->IsFirstStepInVolume();
            
            if (firstStepInVolume)
            {
                trackID = ID;
                x = X;
                y = Y;
                z = Z;
                momentumX = MomentumX;
                momentumY = MomentumY;
                momentumZ = MomentumZ;
                momentumDirectionPhi = MomentumDirectionPhi;
                momentumDirectionTheta = MomentumDirectionTheta;
                energy = Energy;
            }
            
            if(where == fDetector->GetpSDA() && ID == trackID)
            {
                if(nameOfParticle == "e+")
                {
                    std::ofstream filePX("TARGET/P_X.dat", std::ios::app);
                    std::ofstream filePY("TARGET/P_Y.dat", std::ios::app);
                    std::ofstream filePZ("TARGET/P_Z.dat", std::ios::app);
                    std::ofstream filePE("TARGET/P_E.dat", std::ios::app);
                    std::ofstream filePMX("TARGET/P_MX.dat", std::ios::app);
                    std::ofstream filePMY("TARGET/P_MY.dat", std::ios::app);
                    std::ofstream filePMZ("TARGET/P_MZ.dat", std::ios::app);
                    std::ofstream filePP("TARGET/P_P.dat", std::ios::app);
                    std::ofstream filePT("TARGET/P_T.dat", std::ios::app);
                    filePX << std::setw(20) << x << std::endl;
                    filePY << std::setw(20) << y << std::endl;
                    filePZ << std::setw(20) << z << std::endl;
                    filePE << std::setw(20) << energy << std::endl;
                    filePMX << std::setw(20) << momentumX << std::endl;
                    filePMY << std::setw(20) << momentumY << std::endl;
                    filePMZ << std::setw(20) << momentumZ << std::endl;
                    filePP << std::setw(20) << momentumDirectionPhi << std::endl;
                    filePT << std::setw(20) << momentumDirectionTheta << std::endl;
                }
            }
            
            x_pre = step->GetPreStepPoint()->GetPosition().x();
            y_pre = step->GetPreStepPoint()->GetPosition().y();
            z_pre = step->GetPreStepPoint()->GetPosition().z();
            for(G4int k = 0; k < numberOfLayers; ++k)
            {
                for(G4int i = 0; i < orbsInString; ++i)/*(2*i-orbsInString + 1)*rOrb*/
                {
                    for(G4int j = 0; j < orbsInString; ++j)/*(2*j-orbsInString + 1)*rOrb*/
                    {
                        if(((x_pre-((2*i-orbsInString + 1)*rOrb))*(x_pre-((2*i-orbsInString + 1)*rOrb)) +
                            (y_pre-((2*j-orbsInString + 1)*rOrb))*(y_pre-((2*j-orbsInString + 1)*rOrb)) +
                            (z_pre-(k*rOrb*2*std::sqrt(3)))*(z_pre-(k*rOrb*2*std::sqrt(3)))
                           ) <= rOrb*rOrb)
                        {
                            number[i*orbsInString+j+numberOfOrbs*k]++;
                            depEn[i*orbsInString+j+numberOfOrbs*k] += edep;
                        }
                    }
                }
                for(G4int i = 0; i < orbsInString-1; ++i)/*2*rOrb*(i-orbsInString/2+1)*/
                {
                    for(G4int j = 0; j < orbsInString-1; ++j)/*2*rOrb*(j-orbsInString/2+1)*/
                    {
                        if(((x_pre-(2*rOrb*(i-orbsInString/2+1)))*(x_pre-(2*rOrb*(i-orbsInString/2+1))) +
                            (y_pre-(2*rOrb*(j-orbsInString/2+1)))*(y_pre-(2*rOrb*(j-orbsInString/2+1))) +
                            (z_pre-((1 + k*2)*rOrb*std::sqrt(3)))*(z_pre-((1 + k*2)*rOrb*std::sqrt(3)))
                           ) <= rOrb*rOrb)
                        {
                            number[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k]++;
                            depEn[(orbsInString*orbsInString)+i*(orbsInString-1)+j+numberOfOrbs*k] += edep;
                        }
                    }
                }
            }
            
        }
    }
}
